/*
 * Copyright 2020-2025 Typelevel
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package cats.effect

import cats.syntax.all._

import java.nio.channels.SelectableChannel
import java.nio.channels.spi.SelectorProvider

trait Selector {

  /**
   * The [[java.nio.channels.spi.SelectorProvider]] that should be used to create
   * [[java.nio.channels.SelectableChannel]]s that are compatible with this polling system.
   */
  def provider: SelectorProvider

  /**
   * Fiber-block until a [[java.nio.channels.SelectableChannel]] is ready on at least one of the
   * designated operations. The returned value will indicate which operations are ready.
   */
  def select(ch: SelectableChannel, ops: Int): IO[Int]

}

object Selector {
  def find: IO[Option[Selector]] =
    IO.pollers.map(_.collectFirst { case selector: Selector => selector })

  def get = find.flatMap(
    _.liftTo[IO](new RuntimeException("No Selector installed in this IORuntime"))
  )
}
