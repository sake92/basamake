// auto-generated boilerplate by /project/Boilerplate.scala
package cats

/**
 * @groupprio Ungrouped 0
 *
 * @groupname FoldableSlidingN foldable arity
 * @groupdesc FoldableSlidingN
 *   Group sequential elements into fixed sized tuples by passing a "sliding window" over them.
 *
 *   A foldable with fewer elements than the window size will return an empty list unlike `Iterable#sliding(size: Int)`.
 *   Example:
 *   {{{
 *   import cats.Foldable
 *   scala> Foldable[List].sliding2((1 to 10).toList)
 *   val res0: List[(Int, Int)] = List((1,2), (2,3), (3,4), (4,5), (5,6), (6,7), (7,8), (8,9), (9,10))
 *
 *   scala> Foldable[List].sliding4((1 to 10).toList)
 *   val res1: List[(Int, Int, Int, Int)] = List((1,2,3,4), (2,3,4,5), (3,4,5,6), (4,5,6,7), (5,6,7,8), (6,7,8,9), (7,8,9,10))
 *
 *   scala> Foldable[List].sliding4((1 to 2).toList)
 *   val res2: List[(Int, Int, Int, Int)] = List()
 *
 *   }}}
 *
 * @groupprio FoldableSlidingN 999
 *
 */
trait FoldableNFunctions[F[_]] { self: Foldable[F] =>
  private def slidingN[A, B](fa: F[A], n: Int)(f: Seq[A] => B) =
    toIterable(fa).iterator.sliding(n).withPartial(false).map(f).toList

  /** @group FoldableSlidingN */
  def sliding2[A](fa: F[A]): List[(A, A)] =
    slidingN(fa, 2)(x => (x(0), x(1)))
  /** @group FoldableSlidingN */
  def sliding3[A](fa: F[A]): List[(A, A, A)] =
    slidingN(fa, 3)(x => (x(0), x(1), x(2)))
  /** @group FoldableSlidingN */
  def sliding4[A](fa: F[A]): List[(A, A, A, A)] =
    slidingN(fa, 4)(x => (x(0), x(1), x(2), x(3)))
  /** @group FoldableSlidingN */
  def sliding5[A](fa: F[A]): List[(A, A, A, A, A)] =
    slidingN(fa, 5)(x => (x(0), x(1), x(2), x(3), x(4)))
  /** @group FoldableSlidingN */
  def sliding6[A](fa: F[A]): List[(A, A, A, A, A, A)] =
    slidingN(fa, 6)(x => (x(0), x(1), x(2), x(3), x(4), x(5)))
  /** @group FoldableSlidingN */
  def sliding7[A](fa: F[A]): List[(A, A, A, A, A, A, A)] =
    slidingN(fa, 7)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6)))
  /** @group FoldableSlidingN */
  def sliding8[A](fa: F[A]): List[(A, A, A, A, A, A, A, A)] =
    slidingN(fa, 8)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7)))
  /** @group FoldableSlidingN */
  def sliding9[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 9)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8)))
  /** @group FoldableSlidingN */
  def sliding10[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 10)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9)))
  /** @group FoldableSlidingN */
  def sliding11[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 11)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10)))
  /** @group FoldableSlidingN */
  def sliding12[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 12)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10), x(11)))
  /** @group FoldableSlidingN */
  def sliding13[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 13)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10), x(11), x(12)))
  /** @group FoldableSlidingN */
  def sliding14[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 14)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10), x(11), x(12), x(13)))
  /** @group FoldableSlidingN */
  def sliding15[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 15)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10), x(11), x(12), x(13), x(14)))
  /** @group FoldableSlidingN */
  def sliding16[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 16)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10), x(11), x(12), x(13), x(14), x(15)))
  /** @group FoldableSlidingN */
  def sliding17[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 17)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10), x(11), x(12), x(13), x(14), x(15), x(16)))
  /** @group FoldableSlidingN */
  def sliding18[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 18)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10), x(11), x(12), x(13), x(14), x(15), x(16), x(17)))
  /** @group FoldableSlidingN */
  def sliding19[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 19)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10), x(11), x(12), x(13), x(14), x(15), x(16), x(17), x(18)))
  /** @group FoldableSlidingN */
  def sliding20[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 20)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10), x(11), x(12), x(13), x(14), x(15), x(16), x(17), x(18), x(19)))
  /** @group FoldableSlidingN */
  def sliding21[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 21)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10), x(11), x(12), x(13), x(14), x(15), x(16), x(17), x(18), x(19), x(20)))
  /** @group FoldableSlidingN */
  def sliding22[A](fa: F[A]): List[(A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A, A)] =
    slidingN(fa, 22)(x => (x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8), x(9), x(10), x(11), x(12), x(13), x(14), x(15), x(16), x(17), x(18), x(19), x(20), x(21)))
}