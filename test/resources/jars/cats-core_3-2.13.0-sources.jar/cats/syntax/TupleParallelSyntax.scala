// auto-generated boilerplate by /project/Boilerplate.scala
package cats
package syntax

import cats.Parallel

trait TupleParallelSyntax {
  implicit def catsSyntaxTuple1Parallel[M[_], A0](t: Tuple1[M[A0]]): Tuple1ParallelOps[M, A0] = new Tuple1ParallelOps(t)
  implicit def catsSyntaxTuple2Parallel[M[_], A0, A1](t: (M[A0], M[A1])): Tuple2ParallelOps[M, A0, A1] = new Tuple2ParallelOps(t)
  implicit def catsSyntaxTuple3Parallel[M[_], A0, A1, A2](t: (M[A0], M[A1], M[A2])): Tuple3ParallelOps[M, A0, A1, A2] = new Tuple3ParallelOps(t)
  implicit def catsSyntaxTuple4Parallel[M[_], A0, A1, A2, A3](t: (M[A0], M[A1], M[A2], M[A3])): Tuple4ParallelOps[M, A0, A1, A2, A3] = new Tuple4ParallelOps(t)
  implicit def catsSyntaxTuple5Parallel[M[_], A0, A1, A2, A3, A4](t: (M[A0], M[A1], M[A2], M[A3], M[A4])): Tuple5ParallelOps[M, A0, A1, A2, A3, A4] = new Tuple5ParallelOps(t)
  implicit def catsSyntaxTuple6Parallel[M[_], A0, A1, A2, A3, A4, A5](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5])): Tuple6ParallelOps[M, A0, A1, A2, A3, A4, A5] = new Tuple6ParallelOps(t)
  implicit def catsSyntaxTuple7Parallel[M[_], A0, A1, A2, A3, A4, A5, A6](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6])): Tuple7ParallelOps[M, A0, A1, A2, A3, A4, A5, A6] = new Tuple7ParallelOps(t)
  implicit def catsSyntaxTuple8Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7])): Tuple8ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7] = new Tuple8ParallelOps(t)
  implicit def catsSyntaxTuple9Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8])): Tuple9ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8] = new Tuple9ParallelOps(t)
  implicit def catsSyntaxTuple10Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9])): Tuple10ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9] = new Tuple10ParallelOps(t)
  implicit def catsSyntaxTuple11Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10])): Tuple11ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10] = new Tuple11ParallelOps(t)
  implicit def catsSyntaxTuple12Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11])): Tuple12ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11] = new Tuple12ParallelOps(t)
  implicit def catsSyntaxTuple13Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12])): Tuple13ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12] = new Tuple13ParallelOps(t)
  implicit def catsSyntaxTuple14Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13])): Tuple14ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13] = new Tuple14ParallelOps(t)
  implicit def catsSyntaxTuple15Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14])): Tuple15ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14] = new Tuple15ParallelOps(t)
  implicit def catsSyntaxTuple16Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15])): Tuple16ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15] = new Tuple16ParallelOps(t)
  implicit def catsSyntaxTuple17Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15], M[A16])): Tuple17ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16] = new Tuple17ParallelOps(t)
  implicit def catsSyntaxTuple18Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15], M[A16], M[A17])): Tuple18ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17] = new Tuple18ParallelOps(t)
  implicit def catsSyntaxTuple19Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15], M[A16], M[A17], M[A18])): Tuple19ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18] = new Tuple19ParallelOps(t)
  implicit def catsSyntaxTuple20Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15], M[A16], M[A17], M[A18], M[A19])): Tuple20ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19] = new Tuple20ParallelOps(t)
  implicit def catsSyntaxTuple21Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15], M[A16], M[A17], M[A18], M[A19], M[A20])): Tuple21ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20] = new Tuple21ParallelOps(t)
  implicit def catsSyntaxTuple22Parallel[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21](t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15], M[A16], M[A17], M[A18], M[A19], M[A20], M[A21])): Tuple22ParallelOps[M, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21] = new Tuple22ParallelOps(t)
}

private[syntax] final class Tuple1ParallelOps[M[_], A0](private val t: Tuple1[M[A0]]) extends Serializable {
  def parMap[Z](f: (A0) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = p.flatMap.map(t._1)(f)
  
  def parFlatMap[Z](f: (A0) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = p.flatMap.flatMap(t._1)(f)
}
private[syntax] final class Tuple2ParallelOps[M[_], A0, A1](private val t: (M[A0], M[A1])) extends Serializable {
  def parMapN[Z](f: (A0, A1) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap2(t._1, t._2)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1)] = Parallel.parTuple2(t._1, t._2)
  def parFlatMapN[Z](f: (A0, A1) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap2(t._1, t._2)(f)
}
private[syntax] final class Tuple3ParallelOps[M[_], A0, A1, A2](private val t: (M[A0], M[A1], M[A2])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap3(t._1, t._2, t._3)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2)] = Parallel.parTuple3(t._1, t._2, t._3)
  def parFlatMapN[Z](f: (A0, A1, A2) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap3(t._1, t._2, t._3)(f)
}
private[syntax] final class Tuple4ParallelOps[M[_], A0, A1, A2, A3](private val t: (M[A0], M[A1], M[A2], M[A3])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap4(t._1, t._2, t._3, t._4)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3)] = Parallel.parTuple4(t._1, t._2, t._3, t._4)
  def parFlatMapN[Z](f: (A0, A1, A2, A3) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap4(t._1, t._2, t._3, t._4)(f)
}
private[syntax] final class Tuple5ParallelOps[M[_], A0, A1, A2, A3, A4](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap5(t._1, t._2, t._3, t._4, t._5)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4)] = Parallel.parTuple5(t._1, t._2, t._3, t._4, t._5)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap5(t._1, t._2, t._3, t._4, t._5)(f)
}
private[syntax] final class Tuple6ParallelOps[M[_], A0, A1, A2, A3, A4, A5](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap6(t._1, t._2, t._3, t._4, t._5, t._6)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5)] = Parallel.parTuple6(t._1, t._2, t._3, t._4, t._5, t._6)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap6(t._1, t._2, t._3, t._4, t._5, t._6)(f)
}
private[syntax] final class Tuple7ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap7(t._1, t._2, t._3, t._4, t._5, t._6, t._7)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6)] = Parallel.parTuple7(t._1, t._2, t._3, t._4, t._5, t._6, t._7)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap7(t._1, t._2, t._3, t._4, t._5, t._6, t._7)(f)
}
private[syntax] final class Tuple8ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap8(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7)] = Parallel.parTuple8(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap8(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8)(f)
}
private[syntax] final class Tuple9ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap9(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8)] = Parallel.parTuple9(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap9(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9)(f)
}
private[syntax] final class Tuple10ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap10(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9)] = Parallel.parTuple10(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap10(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10)(f)
}
private[syntax] final class Tuple11ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap11(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10)] = Parallel.parTuple11(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap11(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11)(f)
}
private[syntax] final class Tuple12ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap12(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11)] = Parallel.parTuple12(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap12(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12)(f)
}
private[syntax] final class Tuple13ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap13(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12)] = Parallel.parTuple13(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap13(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13)(f)
}
private[syntax] final class Tuple14ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap14(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13)] = Parallel.parTuple14(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap14(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14)(f)
}
private[syntax] final class Tuple15ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap15(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14)] = Parallel.parTuple15(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap15(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15)(f)
}
private[syntax] final class Tuple16ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap16(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15)] = Parallel.parTuple16(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap16(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16)(f)
}
private[syntax] final class Tuple17ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15], M[A16])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap17(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16)] = Parallel.parTuple17(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap17(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17)(f)
}
private[syntax] final class Tuple18ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15], M[A16], M[A17])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap18(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17)] = Parallel.parTuple18(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap18(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18)(f)
}
private[syntax] final class Tuple19ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15], M[A16], M[A17], M[A18])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap19(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18, t._19)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18)] = Parallel.parTuple19(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18, t._19)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap19(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18, t._19)(f)
}
private[syntax] final class Tuple20ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15], M[A16], M[A17], M[A18], M[A19])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap20(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18, t._19, t._20)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19)] = Parallel.parTuple20(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18, t._19, t._20)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap20(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18, t._19, t._20)(f)
}
private[syntax] final class Tuple21ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15], M[A16], M[A17], M[A18], M[A19], M[A20])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap21(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18, t._19, t._20, t._21)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20)] = Parallel.parTuple21(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18, t._19, t._20, t._21)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap21(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18, t._19, t._20, t._21)(f)
}
private[syntax] final class Tuple22ParallelOps[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21](private val t: (M[A0], M[A1], M[A2], M[A3], M[A4], M[A5], M[A6], M[A7], M[A8], M[A9], M[A10], M[A11], M[A12], M[A13], M[A14], M[A15], M[A16], M[A17], M[A18], M[A19], M[A20], M[A21])) extends Serializable {
  def parMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21) => Z)(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parMap22(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18, t._19, t._20, t._21, t._22)(f)
  def parTupled(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21)] = Parallel.parTuple22(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18, t._19, t._20, t._21, t._22)
  def parFlatMapN[Z](f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21) => M[Z])(implicit p: NonEmptyParallel[M]): M[Z] = Parallel.parFlatMap22(t._1, t._2, t._3, t._4, t._5, t._6, t._7, t._8, t._9, t._10, t._11, t._12, t._13, t._14, t._15, t._16, t._17, t._18, t._19, t._20, t._21, t._22)(f)
}
