// auto-generated boilerplate by /project/Boilerplate.scala
package cats
package syntax

import cats.Functor
import cats.Semigroupal

trait FunctionApplySyntax {
  implicit def catsSyntaxFunction1Apply[T, A0](f: Function1[A0, T]): Function1ApplyOps[T, A0] = new Function1ApplyOps(f)
  implicit def catsSyntaxFunction2Apply[T, A0, A1](f: Function2[A0, A1, T]): Function2ApplyOps[T, A0, A1] = new Function2ApplyOps(f)
  implicit def catsSyntaxFunction3Apply[T, A0, A1, A2](f: Function3[A0, A1, A2, T]): Function3ApplyOps[T, A0, A1, A2] = new Function3ApplyOps(f)
  implicit def catsSyntaxFunction4Apply[T, A0, A1, A2, A3](f: Function4[A0, A1, A2, A3, T]): Function4ApplyOps[T, A0, A1, A2, A3] = new Function4ApplyOps(f)
  implicit def catsSyntaxFunction5Apply[T, A0, A1, A2, A3, A4](f: Function5[A0, A1, A2, A3, A4, T]): Function5ApplyOps[T, A0, A1, A2, A3, A4] = new Function5ApplyOps(f)
  implicit def catsSyntaxFunction6Apply[T, A0, A1, A2, A3, A4, A5](f: Function6[A0, A1, A2, A3, A4, A5, T]): Function6ApplyOps[T, A0, A1, A2, A3, A4, A5] = new Function6ApplyOps(f)
  implicit def catsSyntaxFunction7Apply[T, A0, A1, A2, A3, A4, A5, A6](f: Function7[A0, A1, A2, A3, A4, A5, A6, T]): Function7ApplyOps[T, A0, A1, A2, A3, A4, A5, A6] = new Function7ApplyOps(f)
  implicit def catsSyntaxFunction8Apply[T, A0, A1, A2, A3, A4, A5, A6, A7](f: Function8[A0, A1, A2, A3, A4, A5, A6, A7, T]): Function8ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7] = new Function8ApplyOps(f)
  implicit def catsSyntaxFunction9Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8](f: Function9[A0, A1, A2, A3, A4, A5, A6, A7, A8, T]): Function9ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8] = new Function9ApplyOps(f)
  implicit def catsSyntaxFunction10Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](f: Function10[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, T]): Function10ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9] = new Function10ApplyOps(f)
  implicit def catsSyntaxFunction11Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10](f: Function11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, T]): Function11ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10] = new Function11ApplyOps(f)
  implicit def catsSyntaxFunction12Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11](f: Function12[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, T]): Function12ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11] = new Function12ApplyOps(f)
  implicit def catsSyntaxFunction13Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12](f: Function13[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, T]): Function13ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12] = new Function13ApplyOps(f)
  implicit def catsSyntaxFunction14Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13](f: Function14[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, T]): Function14ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13] = new Function14ApplyOps(f)
  implicit def catsSyntaxFunction15Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14](f: Function15[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, T]): Function15ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14] = new Function15ApplyOps(f)
  implicit def catsSyntaxFunction16Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15](f: Function16[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, T]): Function16ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15] = new Function16ApplyOps(f)
  implicit def catsSyntaxFunction17Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16](f: Function17[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, T]): Function17ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16] = new Function17ApplyOps(f)
  implicit def catsSyntaxFunction18Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17](f: Function18[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, T]): Function18ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17] = new Function18ApplyOps(f)
  implicit def catsSyntaxFunction19Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18](f: Function19[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, T]): Function19ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18] = new Function19ApplyOps(f)
  implicit def catsSyntaxFunction20Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19](f: Function20[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, T]): Function20ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19] = new Function20ApplyOps(f)
  implicit def catsSyntaxFunction21Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20](f: Function21[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, T]): Function21ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20] = new Function21ApplyOps(f)
  implicit def catsSyntaxFunction22Apply[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21](f: Function22[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21, T]): Function22ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21] = new Function22ApplyOps(f)
}

private[syntax] final class Function1ApplyOps[T, A0](private val f: Function1[A0, T]) extends AnyVal with Serializable {
  def liftN[F[_]: Functor](a0: F[A0]): F[T] = Functor[F].map(a0)(f)
  def parLiftN[F[_]: Functor](a0: F[A0]): F[T] = Functor[F].map(a0)(f)
}

private[syntax] final class Function2ApplyOps[T, A0, A1](private val f: Function2[A0, A1, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1]): F[T] = Semigroupal.map2(a0, a1)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1]): F[T] = Parallel.parMap2(a0, a1)(f)
}
private[syntax] final class Function3ApplyOps[T, A0, A1, A2](private val f: Function3[A0, A1, A2, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2]): F[T] = Semigroupal.map3(a0, a1, a2)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2]): F[T] = Parallel.parMap3(a0, a1, a2)(f)
}
private[syntax] final class Function4ApplyOps[T, A0, A1, A2, A3](private val f: Function4[A0, A1, A2, A3, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3]): F[T] = Semigroupal.map4(a0, a1, a2, a3)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3]): F[T] = Parallel.parMap4(a0, a1, a2, a3)(f)
}
private[syntax] final class Function5ApplyOps[T, A0, A1, A2, A3, A4](private val f: Function5[A0, A1, A2, A3, A4, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4]): F[T] = Semigroupal.map5(a0, a1, a2, a3, a4)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4]): F[T] = Parallel.parMap5(a0, a1, a2, a3, a4)(f)
}
private[syntax] final class Function6ApplyOps[T, A0, A1, A2, A3, A4, A5](private val f: Function6[A0, A1, A2, A3, A4, A5, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5]): F[T] = Semigroupal.map6(a0, a1, a2, a3, a4, a5)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5]): F[T] = Parallel.parMap6(a0, a1, a2, a3, a4, a5)(f)
}
private[syntax] final class Function7ApplyOps[T, A0, A1, A2, A3, A4, A5, A6](private val f: Function7[A0, A1, A2, A3, A4, A5, A6, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6]): F[T] = Semigroupal.map7(a0, a1, a2, a3, a4, a5, a6)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6]): F[T] = Parallel.parMap7(a0, a1, a2, a3, a4, a5, a6)(f)
}
private[syntax] final class Function8ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7](private val f: Function8[A0, A1, A2, A3, A4, A5, A6, A7, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7]): F[T] = Semigroupal.map8(a0, a1, a2, a3, a4, a5, a6, a7)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7]): F[T] = Parallel.parMap8(a0, a1, a2, a3, a4, a5, a6, a7)(f)
}
private[syntax] final class Function9ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8](private val f: Function9[A0, A1, A2, A3, A4, A5, A6, A7, A8, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8]): F[T] = Semigroupal.map9(a0, a1, a2, a3, a4, a5, a6, a7, a8)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8]): F[T] = Parallel.parMap9(a0, a1, a2, a3, a4, a5, a6, a7, a8)(f)
}
private[syntax] final class Function10ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](private val f: Function10[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9]): F[T] = Semigroupal.map10(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9]): F[T] = Parallel.parMap10(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9)(f)
}
private[syntax] final class Function11ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10](private val f: Function11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10]): F[T] = Semigroupal.map11(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10]): F[T] = Parallel.parMap11(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10)(f)
}
private[syntax] final class Function12ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11](private val f: Function12[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11]): F[T] = Semigroupal.map12(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11]): F[T] = Parallel.parMap12(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11)(f)
}
private[syntax] final class Function13ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12](private val f: Function13[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12]): F[T] = Semigroupal.map13(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12]): F[T] = Parallel.parMap13(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12)(f)
}
private[syntax] final class Function14ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13](private val f: Function14[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13]): F[T] = Semigroupal.map14(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13]): F[T] = Parallel.parMap14(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13)(f)
}
private[syntax] final class Function15ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14](private val f: Function15[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14]): F[T] = Semigroupal.map15(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14]): F[T] = Parallel.parMap15(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14)(f)
}
private[syntax] final class Function16ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15](private val f: Function16[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15]): F[T] = Semigroupal.map16(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15]): F[T] = Parallel.parMap16(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15)(f)
}
private[syntax] final class Function17ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16](private val f: Function17[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15], a16: F[A16]): F[T] = Semigroupal.map17(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15], a16: F[A16]): F[T] = Parallel.parMap17(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16)(f)
}
private[syntax] final class Function18ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17](private val f: Function18[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15], a16: F[A16], a17: F[A17]): F[T] = Semigroupal.map18(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15], a16: F[A16], a17: F[A17]): F[T] = Parallel.parMap18(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17)(f)
}
private[syntax] final class Function19ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18](private val f: Function19[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15], a16: F[A16], a17: F[A17], a18: F[A18]): F[T] = Semigroupal.map19(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15], a16: F[A16], a17: F[A17], a18: F[A18]): F[T] = Parallel.parMap19(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18)(f)
}
private[syntax] final class Function20ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19](private val f: Function20[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15], a16: F[A16], a17: F[A17], a18: F[A18], a19: F[A19]): F[T] = Semigroupal.map20(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15], a16: F[A16], a17: F[A17], a18: F[A18], a19: F[A19]): F[T] = Parallel.parMap20(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19)(f)
}
private[syntax] final class Function21ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20](private val f: Function21[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15], a16: F[A16], a17: F[A17], a18: F[A18], a19: F[A19], a20: F[A20]): F[T] = Semigroupal.map21(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15], a16: F[A16], a17: F[A17], a18: F[A18], a19: F[A19], a20: F[A20]): F[T] = Parallel.parMap21(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20)(f)
}
private[syntax] final class Function22ApplyOps[T, A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21](private val f: Function22[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21, T]) extends AnyVal with Serializable {
 def liftN[F[_]: Functor: Semigroupal](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15], a16: F[A16], a17: F[A17], a18: F[A18], a19: F[A19], a20: F[A20], a21: F[A21]): F[T] = Semigroupal.map22(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, a21)(f)
 def parLiftN[F[_]: Parallel](a0: F[A0], a1: F[A1], a2: F[A2], a3: F[A3], a4: F[A4], a5: F[A5], a6: F[A6], a7: F[A7], a8: F[A8], a9: F[A9], a10: F[A10], a11: F[A11], a12: F[A12], a13: F[A13], a14: F[A14], a15: F[A15], a16: F[A16], a17: F[A17], a18: F[A18], a19: F[A19], a20: F[A20], a21: F[A21]): F[T] = Parallel.parMap22(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, a21)(f)
}