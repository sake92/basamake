// auto-generated boilerplate by /project/Boilerplate.scala
package cats

/**
 * @groupprio Ungrouped 0
 *
 * @groupname FlatMapArity flatMap arity
 * @groupdesc FlatMapArity Higher-arity flatMap methods
 * @groupprio FlatMapArity 999
 */
trait FlatMapArityFunctions[F[_]] { self: FlatMap[F] =>
  /** @group FlatMapArity */
  def flatMap2[A0, A1, Z](f0:F[A0], f1:F[A1])(f: (A0, A1) => F[Z]): F[Z] =
    flatten(map2(f0, f1)(f))
  /** @group FlatMapArity */
  def flatMap3[A0, A1, A2, Z](f0:F[A0], f1:F[A1], f2:F[A2])(f: (A0, A1, A2) => F[Z]): F[Z] =
    flatten(map3(f0, f1, f2)(f))
  /** @group FlatMapArity */
  def flatMap4[A0, A1, A2, A3, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3])(f: (A0, A1, A2, A3) => F[Z]): F[Z] =
    flatten(map4(f0, f1, f2, f3)(f))
  /** @group FlatMapArity */
  def flatMap5[A0, A1, A2, A3, A4, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4])(f: (A0, A1, A2, A3, A4) => F[Z]): F[Z] =
    flatten(map5(f0, f1, f2, f3, f4)(f))
  /** @group FlatMapArity */
  def flatMap6[A0, A1, A2, A3, A4, A5, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5])(f: (A0, A1, A2, A3, A4, A5) => F[Z]): F[Z] =
    flatten(map6(f0, f1, f2, f3, f4, f5)(f))
  /** @group FlatMapArity */
  def flatMap7[A0, A1, A2, A3, A4, A5, A6, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6])(f: (A0, A1, A2, A3, A4, A5, A6) => F[Z]): F[Z] =
    flatten(map7(f0, f1, f2, f3, f4, f5, f6)(f))
  /** @group FlatMapArity */
  def flatMap8[A0, A1, A2, A3, A4, A5, A6, A7, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7])(f: (A0, A1, A2, A3, A4, A5, A6, A7) => F[Z]): F[Z] =
    flatten(map8(f0, f1, f2, f3, f4, f5, f6, f7)(f))
  /** @group FlatMapArity */
  def flatMap9[A0, A1, A2, A3, A4, A5, A6, A7, A8, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8) => F[Z]): F[Z] =
    flatten(map9(f0, f1, f2, f3, f4, f5, f6, f7, f8)(f))
  /** @group FlatMapArity */
  def flatMap10[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8], f9:F[A9])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9) => F[Z]): F[Z] =
    flatten(map10(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9)(f))
  /** @group FlatMapArity */
  def flatMap11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8], f9:F[A9], f10:F[A10])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10) => F[Z]): F[Z] =
    flatten(map11(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10)(f))
  /** @group FlatMapArity */
  def flatMap12[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8], f9:F[A9], f10:F[A10], f11:F[A11])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11) => F[Z]): F[Z] =
    flatten(map12(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11)(f))
  /** @group FlatMapArity */
  def flatMap13[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8], f9:F[A9], f10:F[A10], f11:F[A11], f12:F[A12])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12) => F[Z]): F[Z] =
    flatten(map13(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12)(f))
  /** @group FlatMapArity */
  def flatMap14[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8], f9:F[A9], f10:F[A10], f11:F[A11], f12:F[A12], f13:F[A13])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13) => F[Z]): F[Z] =
    flatten(map14(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13)(f))
  /** @group FlatMapArity */
  def flatMap15[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8], f9:F[A9], f10:F[A10], f11:F[A11], f12:F[A12], f13:F[A13], f14:F[A14])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14) => F[Z]): F[Z] =
    flatten(map15(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14)(f))
  /** @group FlatMapArity */
  def flatMap16[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8], f9:F[A9], f10:F[A10], f11:F[A11], f12:F[A12], f13:F[A13], f14:F[A14], f15:F[A15])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15) => F[Z]): F[Z] =
    flatten(map16(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15)(f))
  /** @group FlatMapArity */
  def flatMap17[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8], f9:F[A9], f10:F[A10], f11:F[A11], f12:F[A12], f13:F[A13], f14:F[A14], f15:F[A15], f16:F[A16])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16) => F[Z]): F[Z] =
    flatten(map17(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16)(f))
  /** @group FlatMapArity */
  def flatMap18[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8], f9:F[A9], f10:F[A10], f11:F[A11], f12:F[A12], f13:F[A13], f14:F[A14], f15:F[A15], f16:F[A16], f17:F[A17])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17) => F[Z]): F[Z] =
    flatten(map18(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16, f17)(f))
  /** @group FlatMapArity */
  def flatMap19[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8], f9:F[A9], f10:F[A10], f11:F[A11], f12:F[A12], f13:F[A13], f14:F[A14], f15:F[A15], f16:F[A16], f17:F[A17], f18:F[A18])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18) => F[Z]): F[Z] =
    flatten(map19(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16, f17, f18)(f))
  /** @group FlatMapArity */
  def flatMap20[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8], f9:F[A9], f10:F[A10], f11:F[A11], f12:F[A12], f13:F[A13], f14:F[A14], f15:F[A15], f16:F[A16], f17:F[A17], f18:F[A18], f19:F[A19])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19) => F[Z]): F[Z] =
    flatten(map20(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16, f17, f18, f19)(f))
  /** @group FlatMapArity */
  def flatMap21[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8], f9:F[A9], f10:F[A10], f11:F[A11], f12:F[A12], f13:F[A13], f14:F[A14], f15:F[A15], f16:F[A16], f17:F[A17], f18:F[A18], f19:F[A19], f20:F[A20])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20) => F[Z]): F[Z] =
    flatten(map21(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16, f17, f18, f19, f20)(f))
  /** @group FlatMapArity */
  def flatMap22[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21, Z](f0:F[A0], f1:F[A1], f2:F[A2], f3:F[A3], f4:F[A4], f5:F[A5], f6:F[A6], f7:F[A7], f8:F[A8], f9:F[A9], f10:F[A10], f11:F[A11], f12:F[A12], f13:F[A13], f14:F[A14], f15:F[A15], f16:F[A16], f17:F[A17], f18:F[A18], f19:F[A19], f20:F[A20], f21:F[A21])(f: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21) => F[Z]): F[Z] =
    flatten(map22(f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16, f17, f18, f19, f20, f21)(f))
}