// auto-generated boilerplate by /project/Boilerplate.scala

package cats
package instances

import cats.kernel.{CommutativeMonoid, CommutativeSemigroup}
import scala.annotation.tailrec

private[cats] trait NTupleMonadInstances extends NTupleMonadInstances1 {

  private def instance[F[_] <: Product](cofMap: (F[Any], F[Any] => Any) => F[Any]): Comonad[F] =
    new Comonad[F] {
      def coflatMap[A, B](fa: F[A])(f: F[A] => B) =
        cofMap(fa.asInstanceOf[F[Any]], f.asInstanceOf[F[Any] => Any]).asInstanceOf[F[B]]
      def extract[A](fa: F[A]) =
        fa.productElement(fa.productArity - 1).asInstanceOf[A]
      def map[A, B](fa: F[A])(f: A => B) =
        coflatMap(fa)(fa => f(extract(fa)))
    }

  implicit final def catsStdInstancesForTuple1: Comonad[Tuple1] =
    instance((fa, f) => fa.copy(_1 = f(fa)))

  implicit final def catsStdInstancesForTuple2[A0]: Comonad[(A0, *)] =
    instance((fa, f) => fa.copy(_2 = f(fa)))

  implicit final def catsStdInstancesForTuple3[A0, A1]: Comonad[(A0, A1, *)] =
    instance((fa, f) => fa.copy(_3 = f(fa)))

  implicit final def catsStdInstancesForTuple4[A0, A1, A2]: Comonad[(A0, A1, A2, *)] =
    instance((fa, f) => fa.copy(_4 = f(fa)))

  implicit final def catsStdInstancesForTuple5[A0, A1, A2, A3]: Comonad[(A0, A1, A2, A3, *)] =
    instance((fa, f) => fa.copy(_5 = f(fa)))

  implicit final def catsStdInstancesForTuple6[A0, A1, A2, A3, A4]: Comonad[(A0, A1, A2, A3, A4, *)] =
    instance((fa, f) => fa.copy(_6 = f(fa)))

  implicit final def catsStdInstancesForTuple7[A0, A1, A2, A3, A4, A5]: Comonad[(A0, A1, A2, A3, A4, A5, *)] =
    instance((fa, f) => fa.copy(_7 = f(fa)))

  implicit final def catsStdInstancesForTuple8[A0, A1, A2, A3, A4, A5, A6]: Comonad[(A0, A1, A2, A3, A4, A5, A6, *)] =
    instance((fa, f) => fa.copy(_8 = f(fa)))

  implicit final def catsStdInstancesForTuple9[A0, A1, A2, A3, A4, A5, A6, A7]: Comonad[(A0, A1, A2, A3, A4, A5, A6, A7, *)] =
    instance((fa, f) => fa.copy(_9 = f(fa)))

  implicit final def catsStdInstancesForTuple10[A0, A1, A2, A3, A4, A5, A6, A7, A8]: Comonad[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *)] =
    instance((fa, f) => fa.copy(_10 = f(fa)))

  implicit final def catsStdInstancesForTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9]: Comonad[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, *)] =
    instance((fa, f) => fa.copy(_11 = f(fa)))
}
private[cats] sealed trait NTupleMonadInstances1 extends NTupleMonadInstances2 { this: NTupleMonadInstances =>
  implicit final def catsStdCommutativeMonadForTuple1: CommutativeMonad[Tuple1] =
    new FlatMapTuple1() with CommutativeMonad[Tuple1] {
      def pure[A](a: A) = Tuple1(a)
    }
  implicit final def catsStdCommutativeMonadForTuple2[A0](implicit A0: CommutativeMonoid[A0]): CommutativeMonad[(A0, *)] =
    new FlatMapTuple2[A0](A0) with CommutativeMonad[(A0, *)] {
      def pure[A](a: A) = (A0.empty, a)
    }
  implicit final def catsStdCommutativeMonadForTuple3[A0, A1](implicit A0: CommutativeMonoid[A0], A1: CommutativeMonoid[A1]): CommutativeMonad[(A0, A1, *)] =
    new FlatMapTuple3[A0, A1](A0, A1) with CommutativeMonad[(A0, A1, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, a)
    }
  implicit final def catsStdCommutativeMonadForTuple4[A0, A1, A2](implicit A0: CommutativeMonoid[A0], A1: CommutativeMonoid[A1], A2: CommutativeMonoid[A2]): CommutativeMonad[(A0, A1, A2, *)] =
    new FlatMapTuple4[A0, A1, A2](A0, A1, A2) with CommutativeMonad[(A0, A1, A2, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, a)
    }
  implicit final def catsStdCommutativeMonadForTuple5[A0, A1, A2, A3](implicit A0: CommutativeMonoid[A0], A1: CommutativeMonoid[A1], A2: CommutativeMonoid[A2], A3: CommutativeMonoid[A3]): CommutativeMonad[(A0, A1, A2, A3, *)] =
    new FlatMapTuple5[A0, A1, A2, A3](A0, A1, A2, A3) with CommutativeMonad[(A0, A1, A2, A3, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, a)
    }
  implicit final def catsStdCommutativeMonadForTuple6[A0, A1, A2, A3, A4](implicit A0: CommutativeMonoid[A0], A1: CommutativeMonoid[A1], A2: CommutativeMonoid[A2], A3: CommutativeMonoid[A3], A4: CommutativeMonoid[A4]): CommutativeMonad[(A0, A1, A2, A3, A4, *)] =
    new FlatMapTuple6[A0, A1, A2, A3, A4](A0, A1, A2, A3, A4) with CommutativeMonad[(A0, A1, A2, A3, A4, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, A4.empty, a)
    }
  implicit final def catsStdCommutativeMonadForTuple7[A0, A1, A2, A3, A4, A5](implicit A0: CommutativeMonoid[A0], A1: CommutativeMonoid[A1], A2: CommutativeMonoid[A2], A3: CommutativeMonoid[A3], A4: CommutativeMonoid[A4], A5: CommutativeMonoid[A5]): CommutativeMonad[(A0, A1, A2, A3, A4, A5, *)] =
    new FlatMapTuple7[A0, A1, A2, A3, A4, A5](A0, A1, A2, A3, A4, A5) with CommutativeMonad[(A0, A1, A2, A3, A4, A5, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, A4.empty, A5.empty, a)
    }
  implicit final def catsStdCommutativeMonadForTuple8[A0, A1, A2, A3, A4, A5, A6](implicit A0: CommutativeMonoid[A0], A1: CommutativeMonoid[A1], A2: CommutativeMonoid[A2], A3: CommutativeMonoid[A3], A4: CommutativeMonoid[A4], A5: CommutativeMonoid[A5], A6: CommutativeMonoid[A6]): CommutativeMonad[(A0, A1, A2, A3, A4, A5, A6, *)] =
    new FlatMapTuple8[A0, A1, A2, A3, A4, A5, A6](A0, A1, A2, A3, A4, A5, A6) with CommutativeMonad[(A0, A1, A2, A3, A4, A5, A6, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, A4.empty, A5.empty, A6.empty, a)
    }
  implicit final def catsStdCommutativeMonadForTuple9[A0, A1, A2, A3, A4, A5, A6, A7](implicit A0: CommutativeMonoid[A0], A1: CommutativeMonoid[A1], A2: CommutativeMonoid[A2], A3: CommutativeMonoid[A3], A4: CommutativeMonoid[A4], A5: CommutativeMonoid[A5], A6: CommutativeMonoid[A6], A7: CommutativeMonoid[A7]): CommutativeMonad[(A0, A1, A2, A3, A4, A5, A6, A7, *)] =
    new FlatMapTuple9[A0, A1, A2, A3, A4, A5, A6, A7](A0, A1, A2, A3, A4, A5, A6, A7) with CommutativeMonad[(A0, A1, A2, A3, A4, A5, A6, A7, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, A4.empty, A5.empty, A6.empty, A7.empty, a)
    }
  implicit final def catsStdCommutativeMonadForTuple10[A0, A1, A2, A3, A4, A5, A6, A7, A8](implicit A0: CommutativeMonoid[A0], A1: CommutativeMonoid[A1], A2: CommutativeMonoid[A2], A3: CommutativeMonoid[A3], A4: CommutativeMonoid[A4], A5: CommutativeMonoid[A5], A6: CommutativeMonoid[A6], A7: CommutativeMonoid[A7], A8: CommutativeMonoid[A8]): CommutativeMonad[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *)] =
    new FlatMapTuple10[A0, A1, A2, A3, A4, A5, A6, A7, A8](A0, A1, A2, A3, A4, A5, A6, A7, A8) with CommutativeMonad[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, A4.empty, A5.empty, A6.empty, A7.empty, A8.empty, a)
    }
  implicit final def catsStdCommutativeMonadForTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](implicit A0: CommutativeMonoid[A0], A1: CommutativeMonoid[A1], A2: CommutativeMonoid[A2], A3: CommutativeMonoid[A3], A4: CommutativeMonoid[A4], A5: CommutativeMonoid[A5], A6: CommutativeMonoid[A6], A7: CommutativeMonoid[A7], A8: CommutativeMonoid[A8], A9: CommutativeMonoid[A9]): CommutativeMonad[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, *)] =
    new FlatMapTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](A0, A1, A2, A3, A4, A5, A6, A7, A8, A9) with CommutativeMonad[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, A4.empty, A5.empty, A6.empty, A7.empty, A8.empty, A9.empty, a)
    }
}
private[cats] sealed trait NTupleMonadInstances2 extends NTupleMonadInstances3 { this: NTupleMonadInstances =>
  implicit final def catsStdCommutativeFlatMapForTuple1: CommutativeFlatMap[Tuple1] =
    new FlatMapTuple1() with CommutativeFlatMap[Tuple1]
  implicit final def catsStdCommutativeFlatMapForTuple2[A0](implicit A0: CommutativeSemigroup[A0]): CommutativeFlatMap[(A0, *)] =
    new FlatMapTuple2[A0](A0) with CommutativeFlatMap[(A0, *)]
  implicit final def catsStdCommutativeFlatMapForTuple3[A0, A1](implicit A0: CommutativeSemigroup[A0], A1: CommutativeSemigroup[A1]): CommutativeFlatMap[(A0, A1, *)] =
    new FlatMapTuple3[A0, A1](A0, A1) with CommutativeFlatMap[(A0, A1, *)]
  implicit final def catsStdCommutativeFlatMapForTuple4[A0, A1, A2](implicit A0: CommutativeSemigroup[A0], A1: CommutativeSemigroup[A1], A2: CommutativeSemigroup[A2]): CommutativeFlatMap[(A0, A1, A2, *)] =
    new FlatMapTuple4[A0, A1, A2](A0, A1, A2) with CommutativeFlatMap[(A0, A1, A2, *)]
  implicit final def catsStdCommutativeFlatMapForTuple5[A0, A1, A2, A3](implicit A0: CommutativeSemigroup[A0], A1: CommutativeSemigroup[A1], A2: CommutativeSemigroup[A2], A3: CommutativeSemigroup[A3]): CommutativeFlatMap[(A0, A1, A2, A3, *)] =
    new FlatMapTuple5[A0, A1, A2, A3](A0, A1, A2, A3) with CommutativeFlatMap[(A0, A1, A2, A3, *)]
  implicit final def catsStdCommutativeFlatMapForTuple6[A0, A1, A2, A3, A4](implicit A0: CommutativeSemigroup[A0], A1: CommutativeSemigroup[A1], A2: CommutativeSemigroup[A2], A3: CommutativeSemigroup[A3], A4: CommutativeSemigroup[A4]): CommutativeFlatMap[(A0, A1, A2, A3, A4, *)] =
    new FlatMapTuple6[A0, A1, A2, A3, A4](A0, A1, A2, A3, A4) with CommutativeFlatMap[(A0, A1, A2, A3, A4, *)]
  implicit final def catsStdCommutativeFlatMapForTuple7[A0, A1, A2, A3, A4, A5](implicit A0: CommutativeSemigroup[A0], A1: CommutativeSemigroup[A1], A2: CommutativeSemigroup[A2], A3: CommutativeSemigroup[A3], A4: CommutativeSemigroup[A4], A5: CommutativeSemigroup[A5]): CommutativeFlatMap[(A0, A1, A2, A3, A4, A5, *)] =
    new FlatMapTuple7[A0, A1, A2, A3, A4, A5](A0, A1, A2, A3, A4, A5) with CommutativeFlatMap[(A0, A1, A2, A3, A4, A5, *)]
  implicit final def catsStdCommutativeFlatMapForTuple8[A0, A1, A2, A3, A4, A5, A6](implicit A0: CommutativeSemigroup[A0], A1: CommutativeSemigroup[A1], A2: CommutativeSemigroup[A2], A3: CommutativeSemigroup[A3], A4: CommutativeSemigroup[A4], A5: CommutativeSemigroup[A5], A6: CommutativeSemigroup[A6]): CommutativeFlatMap[(A0, A1, A2, A3, A4, A5, A6, *)] =
    new FlatMapTuple8[A0, A1, A2, A3, A4, A5, A6](A0, A1, A2, A3, A4, A5, A6) with CommutativeFlatMap[(A0, A1, A2, A3, A4, A5, A6, *)]
  implicit final def catsStdCommutativeFlatMapForTuple9[A0, A1, A2, A3, A4, A5, A6, A7](implicit A0: CommutativeSemigroup[A0], A1: CommutativeSemigroup[A1], A2: CommutativeSemigroup[A2], A3: CommutativeSemigroup[A3], A4: CommutativeSemigroup[A4], A5: CommutativeSemigroup[A5], A6: CommutativeSemigroup[A6], A7: CommutativeSemigroup[A7]): CommutativeFlatMap[(A0, A1, A2, A3, A4, A5, A6, A7, *)] =
    new FlatMapTuple9[A0, A1, A2, A3, A4, A5, A6, A7](A0, A1, A2, A3, A4, A5, A6, A7) with CommutativeFlatMap[(A0, A1, A2, A3, A4, A5, A6, A7, *)]
  implicit final def catsStdCommutativeFlatMapForTuple10[A0, A1, A2, A3, A4, A5, A6, A7, A8](implicit A0: CommutativeSemigroup[A0], A1: CommutativeSemigroup[A1], A2: CommutativeSemigroup[A2], A3: CommutativeSemigroup[A3], A4: CommutativeSemigroup[A4], A5: CommutativeSemigroup[A5], A6: CommutativeSemigroup[A6], A7: CommutativeSemigroup[A7], A8: CommutativeSemigroup[A8]): CommutativeFlatMap[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *)] =
    new FlatMapTuple10[A0, A1, A2, A3, A4, A5, A6, A7, A8](A0, A1, A2, A3, A4, A5, A6, A7, A8) with CommutativeFlatMap[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *)]
  implicit final def catsStdCommutativeFlatMapForTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](implicit A0: CommutativeSemigroup[A0], A1: CommutativeSemigroup[A1], A2: CommutativeSemigroup[A2], A3: CommutativeSemigroup[A3], A4: CommutativeSemigroup[A4], A5: CommutativeSemigroup[A5], A6: CommutativeSemigroup[A6], A7: CommutativeSemigroup[A7], A8: CommutativeSemigroup[A8], A9: CommutativeSemigroup[A9]): CommutativeFlatMap[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, *)] =
    new FlatMapTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](A0, A1, A2, A3, A4, A5, A6, A7, A8, A9) with CommutativeFlatMap[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, *)]
}
private[cats] sealed trait NTupleMonadInstances3 extends NTupleMonadInstances4 { this: NTupleMonadInstances =>
  implicit def catsStdMonadForTuple1: Monad[Tuple1] =
    new FlatMapTuple1() with Monad[Tuple1] {
      def pure[A](a: A) = Tuple1(a)
    }
  implicit def catsStdMonadForTuple2[A0](implicit A0: Monoid[A0]): Monad[(A0, *)] =
    new FlatMapTuple2[A0](A0) with Monad[(A0, *)] {
      def pure[A](a: A) = (A0.empty, a)
    }
  implicit def catsStdMonadForTuple3[A0, A1](implicit A0: Monoid[A0], A1: Monoid[A1]): Monad[(A0, A1, *)] =
    new FlatMapTuple3[A0, A1](A0, A1) with Monad[(A0, A1, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, a)
    }
  implicit def catsStdMonadForTuple4[A0, A1, A2](implicit A0: Monoid[A0], A1: Monoid[A1], A2: Monoid[A2]): Monad[(A0, A1, A2, *)] =
    new FlatMapTuple4[A0, A1, A2](A0, A1, A2) with Monad[(A0, A1, A2, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, a)
    }
  implicit def catsStdMonadForTuple5[A0, A1, A2, A3](implicit A0: Monoid[A0], A1: Monoid[A1], A2: Monoid[A2], A3: Monoid[A3]): Monad[(A0, A1, A2, A3, *)] =
    new FlatMapTuple5[A0, A1, A2, A3](A0, A1, A2, A3) with Monad[(A0, A1, A2, A3, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, a)
    }
  implicit def catsStdMonadForTuple6[A0, A1, A2, A3, A4](implicit A0: Monoid[A0], A1: Monoid[A1], A2: Monoid[A2], A3: Monoid[A3], A4: Monoid[A4]): Monad[(A0, A1, A2, A3, A4, *)] =
    new FlatMapTuple6[A0, A1, A2, A3, A4](A0, A1, A2, A3, A4) with Monad[(A0, A1, A2, A3, A4, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, A4.empty, a)
    }
  implicit def catsStdMonadForTuple7[A0, A1, A2, A3, A4, A5](implicit A0: Monoid[A0], A1: Monoid[A1], A2: Monoid[A2], A3: Monoid[A3], A4: Monoid[A4], A5: Monoid[A5]): Monad[(A0, A1, A2, A3, A4, A5, *)] =
    new FlatMapTuple7[A0, A1, A2, A3, A4, A5](A0, A1, A2, A3, A4, A5) with Monad[(A0, A1, A2, A3, A4, A5, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, A4.empty, A5.empty, a)
    }
  implicit def catsStdMonadForTuple8[A0, A1, A2, A3, A4, A5, A6](implicit A0: Monoid[A0], A1: Monoid[A1], A2: Monoid[A2], A3: Monoid[A3], A4: Monoid[A4], A5: Monoid[A5], A6: Monoid[A6]): Monad[(A0, A1, A2, A3, A4, A5, A6, *)] =
    new FlatMapTuple8[A0, A1, A2, A3, A4, A5, A6](A0, A1, A2, A3, A4, A5, A6) with Monad[(A0, A1, A2, A3, A4, A5, A6, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, A4.empty, A5.empty, A6.empty, a)
    }
  implicit def catsStdMonadForTuple9[A0, A1, A2, A3, A4, A5, A6, A7](implicit A0: Monoid[A0], A1: Monoid[A1], A2: Monoid[A2], A3: Monoid[A3], A4: Monoid[A4], A5: Monoid[A5], A6: Monoid[A6], A7: Monoid[A7]): Monad[(A0, A1, A2, A3, A4, A5, A6, A7, *)] =
    new FlatMapTuple9[A0, A1, A2, A3, A4, A5, A6, A7](A0, A1, A2, A3, A4, A5, A6, A7) with Monad[(A0, A1, A2, A3, A4, A5, A6, A7, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, A4.empty, A5.empty, A6.empty, A7.empty, a)
    }
  implicit def catsStdMonadForTuple10[A0, A1, A2, A3, A4, A5, A6, A7, A8](implicit A0: Monoid[A0], A1: Monoid[A1], A2: Monoid[A2], A3: Monoid[A3], A4: Monoid[A4], A5: Monoid[A5], A6: Monoid[A6], A7: Monoid[A7], A8: Monoid[A8]): Monad[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *)] =
    new FlatMapTuple10[A0, A1, A2, A3, A4, A5, A6, A7, A8](A0, A1, A2, A3, A4, A5, A6, A7, A8) with Monad[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, A4.empty, A5.empty, A6.empty, A7.empty, A8.empty, a)
    }
  implicit def catsStdMonadForTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](implicit A0: Monoid[A0], A1: Monoid[A1], A2: Monoid[A2], A3: Monoid[A3], A4: Monoid[A4], A5: Monoid[A5], A6: Monoid[A6], A7: Monoid[A7], A8: Monoid[A8], A9: Monoid[A9]): Monad[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, *)] =
    new FlatMapTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](A0, A1, A2, A3, A4, A5, A6, A7, A8, A9) with Monad[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, *)] {
      def pure[A](a: A) = (A0.empty, A1.empty, A2.empty, A3.empty, A4.empty, A5.empty, A6.empty, A7.empty, A8.empty, A9.empty, a)
    }
}
private[cats] sealed trait NTupleMonadInstances4 extends NTupleMonadInstances5 { this: NTupleMonadInstances =>
  implicit def catsStdFlatMapForTuple1: FlatMap[Tuple1] =
    new FlatMapTuple1()
  implicit def catsStdFlatMapForTuple2[A0](implicit A0: Semigroup[A0]): FlatMap[(A0, *)] =
    new FlatMapTuple2[A0](A0)
  implicit def catsStdFlatMapForTuple3[A0, A1](implicit A0: Semigroup[A0], A1: Semigroup[A1]): FlatMap[(A0, A1, *)] =
    new FlatMapTuple3[A0, A1](A0, A1)
  implicit def catsStdFlatMapForTuple4[A0, A1, A2](implicit A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2]): FlatMap[(A0, A1, A2, *)] =
    new FlatMapTuple4[A0, A1, A2](A0, A1, A2)
  implicit def catsStdFlatMapForTuple5[A0, A1, A2, A3](implicit A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3]): FlatMap[(A0, A1, A2, A3, *)] =
    new FlatMapTuple5[A0, A1, A2, A3](A0, A1, A2, A3)
  implicit def catsStdFlatMapForTuple6[A0, A1, A2, A3, A4](implicit A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3], A4: Semigroup[A4]): FlatMap[(A0, A1, A2, A3, A4, *)] =
    new FlatMapTuple6[A0, A1, A2, A3, A4](A0, A1, A2, A3, A4)
  implicit def catsStdFlatMapForTuple7[A0, A1, A2, A3, A4, A5](implicit A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3], A4: Semigroup[A4], A5: Semigroup[A5]): FlatMap[(A0, A1, A2, A3, A4, A5, *)] =
    new FlatMapTuple7[A0, A1, A2, A3, A4, A5](A0, A1, A2, A3, A4, A5)
  implicit def catsStdFlatMapForTuple8[A0, A1, A2, A3, A4, A5, A6](implicit A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3], A4: Semigroup[A4], A5: Semigroup[A5], A6: Semigroup[A6]): FlatMap[(A0, A1, A2, A3, A4, A5, A6, *)] =
    new FlatMapTuple8[A0, A1, A2, A3, A4, A5, A6](A0, A1, A2, A3, A4, A5, A6)
  implicit def catsStdFlatMapForTuple9[A0, A1, A2, A3, A4, A5, A6, A7](implicit A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3], A4: Semigroup[A4], A5: Semigroup[A5], A6: Semigroup[A6], A7: Semigroup[A7]): FlatMap[(A0, A1, A2, A3, A4, A5, A6, A7, *)] =
    new FlatMapTuple9[A0, A1, A2, A3, A4, A5, A6, A7](A0, A1, A2, A3, A4, A5, A6, A7)
  implicit def catsStdFlatMapForTuple10[A0, A1, A2, A3, A4, A5, A6, A7, A8](implicit A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3], A4: Semigroup[A4], A5: Semigroup[A5], A6: Semigroup[A6], A7: Semigroup[A7], A8: Semigroup[A8]): FlatMap[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *)] =
    new FlatMapTuple10[A0, A1, A2, A3, A4, A5, A6, A7, A8](A0, A1, A2, A3, A4, A5, A6, A7, A8)
  implicit def catsStdFlatMapForTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](implicit A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3], A4: Semigroup[A4], A5: Semigroup[A5], A6: Semigroup[A6], A7: Semigroup[A7], A8: Semigroup[A8], A9: Semigroup[A9]): FlatMap[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, *)] =
    new FlatMapTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](A0, A1, A2, A3, A4, A5, A6, A7, A8, A9)
}
private[cats] sealed trait NTupleMonadInstances5 { this: NTupleMonadInstances =>
  implicit def catsStdInvariantForTuple1: Invariant[Tuple1] =
    catsStdInstancesForTuple1
  implicit def catsStdInvariantForTuple2[A0]: Invariant[(A0, *)] =
    catsStdInstancesForTuple2
  implicit def catsStdInvariantForTuple3[A0, A1]: Invariant[(A0, A1, *)] =
    catsStdInstancesForTuple3
  implicit def catsStdInvariantForTuple4[A0, A1, A2]: Invariant[(A0, A1, A2, *)] =
    catsStdInstancesForTuple4
  implicit def catsStdInvariantForTuple5[A0, A1, A2, A3]: Invariant[(A0, A1, A2, A3, *)] =
    catsStdInstancesForTuple5
  implicit def catsStdInvariantForTuple6[A0, A1, A2, A3, A4]: Invariant[(A0, A1, A2, A3, A4, *)] =
    catsStdInstancesForTuple6
  implicit def catsStdInvariantForTuple7[A0, A1, A2, A3, A4, A5]: Invariant[(A0, A1, A2, A3, A4, A5, *)] =
    catsStdInstancesForTuple7
  implicit def catsStdInvariantForTuple8[A0, A1, A2, A3, A4, A5, A6]: Invariant[(A0, A1, A2, A3, A4, A5, A6, *)] =
    catsStdInstancesForTuple8
  implicit def catsStdInvariantForTuple9[A0, A1, A2, A3, A4, A5, A6, A7]: Invariant[(A0, A1, A2, A3, A4, A5, A6, A7, *)] =
    catsStdInstancesForTuple9
  implicit def catsStdInvariantForTuple10[A0, A1, A2, A3, A4, A5, A6, A7, A8]: Invariant[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *)] =
    catsStdInstancesForTuple10
  implicit def catsStdInvariantForTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9]: Invariant[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, *)] =
    catsStdInstancesForTuple11
}

private[instances] class FlatMapTuple1()
    extends FlatMap[Tuple1] {
  override def ap[A, B](ff: Tuple1[A => B])(fa: Tuple1[A]) =
    Tuple1(ff._1(fa._1))
  override def product[A, B](fa: Tuple1[A], fb: Tuple1[B]) =
    Tuple1((fa._1, fb._1))
  override def map[A, B](fa: Tuple1[A])(f: A => B) =
    fa.copy(_1 = f(fa._1))
  def flatMap[A, B](fa: Tuple1[A])(f: A => Tuple1[B]) = {
    val xb = f(fa._1)
    Tuple1(xb._1)
  }
  override def productR[A, B](a: Tuple1[A])(b: Tuple1[B]) =
    Tuple1(b._1)
  override def productL[A, B](a: Tuple1[A])(b: Tuple1[B]) =
    Tuple1(a._1)
  override def mproduct[A, B](fa: Tuple1[A])(f: A => Tuple1[B]) = {
    val xb = f(fa._1)
    Tuple1((fa._1, xb._1))
  }
  def tailRecM[A, B](a: A)(f: A => Tuple1[Either[A, B]]) = {
    
    @tailrec
    def loop(a: A): Tuple1[B] =
      f(a) match {
        case Tuple1(Right(b))    => Tuple1(b)
        case Tuple1(Left(nextA)) => loop(nextA)
      }
    loop(a)
  }
}

private[instances] class FlatMapNTuple2[A0](A0: Semigroup[A0])
    extends FlatMap[(A0, *)] {
  override def ap[A, B](ff: (A0, A => B))(fa: (A0, A)) =
    (A0.combine(ff._1, fa._1), ff._2(fa._2))
  override def product[A, B](fa: (A0, A), fb: (A0, B)) =
    (A0.combine(fa._1, fb._1), (fa._2, fb._2))
  override def map[A, B](fa: (A0, A))(f: A => B) =
    fa.copy(_2 = f(fa._2))
  def flatMap[A, B](fa: (A0, A))(f: A => (A0, B)) = {
    val xb = f(fa._2)
    (A0.combine(fa._1, xb._1), xb._2)
  }
  override def productR[A, B](a: (A0, A))(b: (A0, B)) =
    (A0.combine(a._1, b._1), b._2)
  override def productL[A, B](a: (A0, A))(b: (A0, B)) =
    (A0.combine(a._1, b._1), a._2)
  override def mproduct[A, B](fa: (A0, A))(f: A => (A0, B)) = {
    val xb = f(fa._2)
    (A0.combine(fa._1, xb._1), (fa._2, xb._2))
  }
  def tailRecM[A, B](a: A)(f: A => (A0, Either[A, B])) = {
    
    @tailrec
    def loop(b0: A0, a: A): (A0, B) =
      f(a) match {
        case (a0, Right(b))    => (A0.combine(b0, a0), b)
        case (a0, Left(nextA)) => loop(A0.combine(b0, a0), nextA)
      }
    f(a) match {
      case (a0, Right(b))    => (a0, b)
      case (a0, Left(nextA)) => loop(a0, nextA)
    }
  }
}

private[instances] class FlatMapTuple3[A0, A1](A0: Semigroup[A0], A1: Semigroup[A1])
    extends FlatMap[(A0, A1, *)] {
  override def ap[A, B](ff: (A0, A1, A => B))(fa: (A0, A1, A)) =
    (A0.combine(ff._1, fa._1), A1.combine(ff._2, fa._2), ff._3(fa._3))
  override def product[A, B](fa: (A0, A1, A), fb: (A0, A1, B)) =
    (A0.combine(fa._1, fb._1), A1.combine(fa._2, fb._2), (fa._3, fb._3))
  override def map[A, B](fa: (A0, A1, A))(f: A => B) =
    fa.copy(_3 = f(fa._3))
  def flatMap[A, B](fa: (A0, A1, A))(f: A => (A0, A1, B)) = {
    val xb = f(fa._3)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), xb._3)
  }
  override def productR[A, B](a: (A0, A1, A))(b: (A0, A1, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), b._3)
  override def productL[A, B](a: (A0, A1, A))(b: (A0, A1, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), a._3)
  override def mproduct[A, B](fa: (A0, A1, A))(f: A => (A0, A1, B)) = {
    val xb = f(fa._3)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), (fa._3, xb._3))
  }
  def tailRecM[A, B](a: A)(f: A => (A0, A1, Either[A, B])) = {
    
    @tailrec
    def loop(b0: A0, b1: A1, a: A): (A0, A1, B) =
      f(a) match {
        case (a0, a1, Right(b))    => (A0.combine(b0, a0), A1.combine(b1, a1), b)
        case (a0, a1, Left(nextA)) => loop(A0.combine(b0, a0), A1.combine(b1, a1), nextA)
      }
    f(a) match {
      case (a0, a1, Right(b))    => (a0, a1, b)
      case (a0, a1, Left(nextA)) => loop(a0, a1, nextA)
    }
  }
}

private[instances] class FlatMapTuple4[A0, A1, A2](A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2])
    extends FlatMap[(A0, A1, A2, *)] {
  override def ap[A, B](ff: (A0, A1, A2, A => B))(fa: (A0, A1, A2, A)) =
    (A0.combine(ff._1, fa._1), A1.combine(ff._2, fa._2), A2.combine(ff._3, fa._3), ff._4(fa._4))
  override def product[A, B](fa: (A0, A1, A2, A), fb: (A0, A1, A2, B)) =
    (A0.combine(fa._1, fb._1), A1.combine(fa._2, fb._2), A2.combine(fa._3, fb._3), (fa._4, fb._4))
  override def map[A, B](fa: (A0, A1, A2, A))(f: A => B) =
    fa.copy(_4 = f(fa._4))
  def flatMap[A, B](fa: (A0, A1, A2, A))(f: A => (A0, A1, A2, B)) = {
    val xb = f(fa._4)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), xb._4)
  }
  override def productR[A, B](a: (A0, A1, A2, A))(b: (A0, A1, A2, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), b._4)
  override def productL[A, B](a: (A0, A1, A2, A))(b: (A0, A1, A2, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), a._4)
  override def mproduct[A, B](fa: (A0, A1, A2, A))(f: A => (A0, A1, A2, B)) = {
    val xb = f(fa._4)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), (fa._4, xb._4))
  }
  def tailRecM[A, B](a: A)(f: A => (A0, A1, A2, Either[A, B])) = {
    
    @tailrec
    def loop(b0: A0, b1: A1, b2: A2, a: A): (A0, A1, A2, B) =
      f(a) match {
        case (a0, a1, a2, Right(b))    => (A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), b)
        case (a0, a1, a2, Left(nextA)) => loop(A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), nextA)
      }
    f(a) match {
      case (a0, a1, a2, Right(b))    => (a0, a1, a2, b)
      case (a0, a1, a2, Left(nextA)) => loop(a0, a1, a2, nextA)
    }
  }
}

private[instances] class FlatMapTuple5[A0, A1, A2, A3](A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3])
    extends FlatMap[(A0, A1, A2, A3, *)] {
  override def ap[A, B](ff: (A0, A1, A2, A3, A => B))(fa: (A0, A1, A2, A3, A)) =
    (A0.combine(ff._1, fa._1), A1.combine(ff._2, fa._2), A2.combine(ff._3, fa._3), A3.combine(ff._4, fa._4), ff._5(fa._5))
  override def product[A, B](fa: (A0, A1, A2, A3, A), fb: (A0, A1, A2, A3, B)) =
    (A0.combine(fa._1, fb._1), A1.combine(fa._2, fb._2), A2.combine(fa._3, fb._3), A3.combine(fa._4, fb._4), (fa._5, fb._5))
  override def map[A, B](fa: (A0, A1, A2, A3, A))(f: A => B) =
    fa.copy(_5 = f(fa._5))
  def flatMap[A, B](fa: (A0, A1, A2, A3, A))(f: A => (A0, A1, A2, A3, B)) = {
    val xb = f(fa._5)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), xb._5)
  }
  override def productR[A, B](a: (A0, A1, A2, A3, A))(b: (A0, A1, A2, A3, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), b._5)
  override def productL[A, B](a: (A0, A1, A2, A3, A))(b: (A0, A1, A2, A3, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), a._5)
  override def mproduct[A, B](fa: (A0, A1, A2, A3, A))(f: A => (A0, A1, A2, A3, B)) = {
    val xb = f(fa._5)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), (fa._5, xb._5))
  }
  def tailRecM[A, B](a: A)(f: A => (A0, A1, A2, A3, Either[A, B])) = {
    
    @tailrec
    def loop(b0: A0, b1: A1, b2: A2, b3: A3, a: A): (A0, A1, A2, A3, B) =
      f(a) match {
        case (a0, a1, a2, a3, Right(b))    => (A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), b)
        case (a0, a1, a2, a3, Left(nextA)) => loop(A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), nextA)
      }
    f(a) match {
      case (a0, a1, a2, a3, Right(b))    => (a0, a1, a2, a3, b)
      case (a0, a1, a2, a3, Left(nextA)) => loop(a0, a1, a2, a3, nextA)
    }
  }
}

private[instances] class FlatMapTuple6[A0, A1, A2, A3, A4](A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3], A4: Semigroup[A4])
    extends FlatMap[(A0, A1, A2, A3, A4, *)] {
  override def ap[A, B](ff: (A0, A1, A2, A3, A4, A => B))(fa: (A0, A1, A2, A3, A4, A)) =
    (A0.combine(ff._1, fa._1), A1.combine(ff._2, fa._2), A2.combine(ff._3, fa._3), A3.combine(ff._4, fa._4), A4.combine(ff._5, fa._5), ff._6(fa._6))
  override def product[A, B](fa: (A0, A1, A2, A3, A4, A), fb: (A0, A1, A2, A3, A4, B)) =
    (A0.combine(fa._1, fb._1), A1.combine(fa._2, fb._2), A2.combine(fa._3, fb._3), A3.combine(fa._4, fb._4), A4.combine(fa._5, fb._5), (fa._6, fb._6))
  override def map[A, B](fa: (A0, A1, A2, A3, A4, A))(f: A => B) =
    fa.copy(_6 = f(fa._6))
  def flatMap[A, B](fa: (A0, A1, A2, A3, A4, A))(f: A => (A0, A1, A2, A3, A4, B)) = {
    val xb = f(fa._6)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), A4.combine(fa._5, xb._5), xb._6)
  }
  override def productR[A, B](a: (A0, A1, A2, A3, A4, A))(b: (A0, A1, A2, A3, A4, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), A4.combine(a._5, b._5), b._6)
  override def productL[A, B](a: (A0, A1, A2, A3, A4, A))(b: (A0, A1, A2, A3, A4, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), A4.combine(a._5, b._5), a._6)
  override def mproduct[A, B](fa: (A0, A1, A2, A3, A4, A))(f: A => (A0, A1, A2, A3, A4, B)) = {
    val xb = f(fa._6)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), A4.combine(fa._5, xb._5), (fa._6, xb._6))
  }
  def tailRecM[A, B](a: A)(f: A => (A0, A1, A2, A3, A4, Either[A, B])) = {
    
    @tailrec
    def loop(b0: A0, b1: A1, b2: A2, b3: A3, b4: A4, a: A): (A0, A1, A2, A3, A4, B) =
      f(a) match {
        case (a0, a1, a2, a3, a4, Right(b))    => (A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), A4.combine(b4, a4), b)
        case (a0, a1, a2, a3, a4, Left(nextA)) => loop(A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), A4.combine(b4, a4), nextA)
      }
    f(a) match {
      case (a0, a1, a2, a3, a4, Right(b))    => (a0, a1, a2, a3, a4, b)
      case (a0, a1, a2, a3, a4, Left(nextA)) => loop(a0, a1, a2, a3, a4, nextA)
    }
  }
}

private[instances] class FlatMapTuple7[A0, A1, A2, A3, A4, A5](A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3], A4: Semigroup[A4], A5: Semigroup[A5])
    extends FlatMap[(A0, A1, A2, A3, A4, A5, *)] {
  override def ap[A, B](ff: (A0, A1, A2, A3, A4, A5, A => B))(fa: (A0, A1, A2, A3, A4, A5, A)) =
    (A0.combine(ff._1, fa._1), A1.combine(ff._2, fa._2), A2.combine(ff._3, fa._3), A3.combine(ff._4, fa._4), A4.combine(ff._5, fa._5), A5.combine(ff._6, fa._6), ff._7(fa._7))
  override def product[A, B](fa: (A0, A1, A2, A3, A4, A5, A), fb: (A0, A1, A2, A3, A4, A5, B)) =
    (A0.combine(fa._1, fb._1), A1.combine(fa._2, fb._2), A2.combine(fa._3, fb._3), A3.combine(fa._4, fb._4), A4.combine(fa._5, fb._5), A5.combine(fa._6, fb._6), (fa._7, fb._7))
  override def map[A, B](fa: (A0, A1, A2, A3, A4, A5, A))(f: A => B) =
    fa.copy(_7 = f(fa._7))
  def flatMap[A, B](fa: (A0, A1, A2, A3, A4, A5, A))(f: A => (A0, A1, A2, A3, A4, A5, B)) = {
    val xb = f(fa._7)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), A4.combine(fa._5, xb._5), A5.combine(fa._6, xb._6), xb._7)
  }
  override def productR[A, B](a: (A0, A1, A2, A3, A4, A5, A))(b: (A0, A1, A2, A3, A4, A5, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), A4.combine(a._5, b._5), A5.combine(a._6, b._6), b._7)
  override def productL[A, B](a: (A0, A1, A2, A3, A4, A5, A))(b: (A0, A1, A2, A3, A4, A5, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), A4.combine(a._5, b._5), A5.combine(a._6, b._6), a._7)
  override def mproduct[A, B](fa: (A0, A1, A2, A3, A4, A5, A))(f: A => (A0, A1, A2, A3, A4, A5, B)) = {
    val xb = f(fa._7)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), A4.combine(fa._5, xb._5), A5.combine(fa._6, xb._6), (fa._7, xb._7))
  }
  def tailRecM[A, B](a: A)(f: A => (A0, A1, A2, A3, A4, A5, Either[A, B])) = {
    
    @tailrec
    def loop(b0: A0, b1: A1, b2: A2, b3: A3, b4: A4, b5: A5, a: A): (A0, A1, A2, A3, A4, A5, B) =
      f(a) match {
        case (a0, a1, a2, a3, a4, a5, Right(b))    => (A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), A4.combine(b4, a4), A5.combine(b5, a5), b)
        case (a0, a1, a2, a3, a4, a5, Left(nextA)) => loop(A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), A4.combine(b4, a4), A5.combine(b5, a5), nextA)
      }
    f(a) match {
      case (a0, a1, a2, a3, a4, a5, Right(b))    => (a0, a1, a2, a3, a4, a5, b)
      case (a0, a1, a2, a3, a4, a5, Left(nextA)) => loop(a0, a1, a2, a3, a4, a5, nextA)
    }
  }
}

private[instances] class FlatMapTuple8[A0, A1, A2, A3, A4, A5, A6](A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3], A4: Semigroup[A4], A5: Semigroup[A5], A6: Semigroup[A6])
    extends FlatMap[(A0, A1, A2, A3, A4, A5, A6, *)] {
  override def ap[A, B](ff: (A0, A1, A2, A3, A4, A5, A6, A => B))(fa: (A0, A1, A2, A3, A4, A5, A6, A)) =
    (A0.combine(ff._1, fa._1), A1.combine(ff._2, fa._2), A2.combine(ff._3, fa._3), A3.combine(ff._4, fa._4), A4.combine(ff._5, fa._5), A5.combine(ff._6, fa._6), A6.combine(ff._7, fa._7), ff._8(fa._8))
  override def product[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A), fb: (A0, A1, A2, A3, A4, A5, A6, B)) =
    (A0.combine(fa._1, fb._1), A1.combine(fa._2, fb._2), A2.combine(fa._3, fb._3), A3.combine(fa._4, fb._4), A4.combine(fa._5, fb._5), A5.combine(fa._6, fb._6), A6.combine(fa._7, fb._7), (fa._8, fb._8))
  override def map[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A))(f: A => B) =
    fa.copy(_8 = f(fa._8))
  def flatMap[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A))(f: A => (A0, A1, A2, A3, A4, A5, A6, B)) = {
    val xb = f(fa._8)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), A4.combine(fa._5, xb._5), A5.combine(fa._6, xb._6), A6.combine(fa._7, xb._7), xb._8)
  }
  override def productR[A, B](a: (A0, A1, A2, A3, A4, A5, A6, A))(b: (A0, A1, A2, A3, A4, A5, A6, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), A4.combine(a._5, b._5), A5.combine(a._6, b._6), A6.combine(a._7, b._7), b._8)
  override def productL[A, B](a: (A0, A1, A2, A3, A4, A5, A6, A))(b: (A0, A1, A2, A3, A4, A5, A6, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), A4.combine(a._5, b._5), A5.combine(a._6, b._6), A6.combine(a._7, b._7), a._8)
  override def mproduct[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A))(f: A => (A0, A1, A2, A3, A4, A5, A6, B)) = {
    val xb = f(fa._8)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), A4.combine(fa._5, xb._5), A5.combine(fa._6, xb._6), A6.combine(fa._7, xb._7), (fa._8, xb._8))
  }
  def tailRecM[A, B](a: A)(f: A => (A0, A1, A2, A3, A4, A5, A6, Either[A, B])) = {
    
    @tailrec
    def loop(b0: A0, b1: A1, b2: A2, b3: A3, b4: A4, b5: A5, b6: A6, a: A): (A0, A1, A2, A3, A4, A5, A6, B) =
      f(a) match {
        case (a0, a1, a2, a3, a4, a5, a6, Right(b))    => (A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), A4.combine(b4, a4), A5.combine(b5, a5), A6.combine(b6, a6), b)
        case (a0, a1, a2, a3, a4, a5, a6, Left(nextA)) => loop(A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), A4.combine(b4, a4), A5.combine(b5, a5), A6.combine(b6, a6), nextA)
      }
    f(a) match {
      case (a0, a1, a2, a3, a4, a5, a6, Right(b))    => (a0, a1, a2, a3, a4, a5, a6, b)
      case (a0, a1, a2, a3, a4, a5, a6, Left(nextA)) => loop(a0, a1, a2, a3, a4, a5, a6, nextA)
    }
  }
}

private[instances] class FlatMapTuple9[A0, A1, A2, A3, A4, A5, A6, A7](A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3], A4: Semigroup[A4], A5: Semigroup[A5], A6: Semigroup[A6], A7: Semigroup[A7])
    extends FlatMap[(A0, A1, A2, A3, A4, A5, A6, A7, *)] {
  override def ap[A, B](ff: (A0, A1, A2, A3, A4, A5, A6, A7, A => B))(fa: (A0, A1, A2, A3, A4, A5, A6, A7, A)) =
    (A0.combine(ff._1, fa._1), A1.combine(ff._2, fa._2), A2.combine(ff._3, fa._3), A3.combine(ff._4, fa._4), A4.combine(ff._5, fa._5), A5.combine(ff._6, fa._6), A6.combine(ff._7, fa._7), A7.combine(ff._8, fa._8), ff._9(fa._9))
  override def product[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A7, A), fb: (A0, A1, A2, A3, A4, A5, A6, A7, B)) =
    (A0.combine(fa._1, fb._1), A1.combine(fa._2, fb._2), A2.combine(fa._3, fb._3), A3.combine(fa._4, fb._4), A4.combine(fa._5, fb._5), A5.combine(fa._6, fb._6), A6.combine(fa._7, fb._7), A7.combine(fa._8, fb._8), (fa._9, fb._9))
  override def map[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A7, A))(f: A => B) =
    fa.copy(_9 = f(fa._9))
  def flatMap[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A7, A))(f: A => (A0, A1, A2, A3, A4, A5, A6, A7, B)) = {
    val xb = f(fa._9)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), A4.combine(fa._5, xb._5), A5.combine(fa._6, xb._6), A6.combine(fa._7, xb._7), A7.combine(fa._8, xb._8), xb._9)
  }
  override def productR[A, B](a: (A0, A1, A2, A3, A4, A5, A6, A7, A))(b: (A0, A1, A2, A3, A4, A5, A6, A7, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), A4.combine(a._5, b._5), A5.combine(a._6, b._6), A6.combine(a._7, b._7), A7.combine(a._8, b._8), b._9)
  override def productL[A, B](a: (A0, A1, A2, A3, A4, A5, A6, A7, A))(b: (A0, A1, A2, A3, A4, A5, A6, A7, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), A4.combine(a._5, b._5), A5.combine(a._6, b._6), A6.combine(a._7, b._7), A7.combine(a._8, b._8), a._9)
  override def mproduct[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A7, A))(f: A => (A0, A1, A2, A3, A4, A5, A6, A7, B)) = {
    val xb = f(fa._9)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), A4.combine(fa._5, xb._5), A5.combine(fa._6, xb._6), A6.combine(fa._7, xb._7), A7.combine(fa._8, xb._8), (fa._9, xb._9))
  }
  def tailRecM[A, B](a: A)(f: A => (A0, A1, A2, A3, A4, A5, A6, A7, Either[A, B])) = {
    
    @tailrec
    def loop(b0: A0, b1: A1, b2: A2, b3: A3, b4: A4, b5: A5, b6: A6, b7: A7, a: A): (A0, A1, A2, A3, A4, A5, A6, A7, B) =
      f(a) match {
        case (a0, a1, a2, a3, a4, a5, a6, a7, Right(b))    => (A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), A4.combine(b4, a4), A5.combine(b5, a5), A6.combine(b6, a6), A7.combine(b7, a7), b)
        case (a0, a1, a2, a3, a4, a5, a6, a7, Left(nextA)) => loop(A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), A4.combine(b4, a4), A5.combine(b5, a5), A6.combine(b6, a6), A7.combine(b7, a7), nextA)
      }
    f(a) match {
      case (a0, a1, a2, a3, a4, a5, a6, a7, Right(b))    => (a0, a1, a2, a3, a4, a5, a6, a7, b)
      case (a0, a1, a2, a3, a4, a5, a6, a7, Left(nextA)) => loop(a0, a1, a2, a3, a4, a5, a6, a7, nextA)
    }
  }
}

private[instances] class FlatMapTuple10[A0, A1, A2, A3, A4, A5, A6, A7, A8](A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3], A4: Semigroup[A4], A5: Semigroup[A5], A6: Semigroup[A6], A7: Semigroup[A7], A8: Semigroup[A8])
    extends FlatMap[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *)] {
  override def ap[A, B](ff: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A => B))(fa: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A)) =
    (A0.combine(ff._1, fa._1), A1.combine(ff._2, fa._2), A2.combine(ff._3, fa._3), A3.combine(ff._4, fa._4), A4.combine(ff._5, fa._5), A5.combine(ff._6, fa._6), A6.combine(ff._7, fa._7), A7.combine(ff._8, fa._8), A8.combine(ff._9, fa._9), ff._10(fa._10))
  override def product[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A), fb: (A0, A1, A2, A3, A4, A5, A6, A7, A8, B)) =
    (A0.combine(fa._1, fb._1), A1.combine(fa._2, fb._2), A2.combine(fa._3, fb._3), A3.combine(fa._4, fb._4), A4.combine(fa._5, fb._5), A5.combine(fa._6, fb._6), A6.combine(fa._7, fb._7), A7.combine(fa._8, fb._8), A8.combine(fa._9, fb._9), (fa._10, fb._10))
  override def map[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A))(f: A => B) =
    fa.copy(_10 = f(fa._10))
  def flatMap[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A))(f: A => (A0, A1, A2, A3, A4, A5, A6, A7, A8, B)) = {
    val xb = f(fa._10)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), A4.combine(fa._5, xb._5), A5.combine(fa._6, xb._6), A6.combine(fa._7, xb._7), A7.combine(fa._8, xb._8), A8.combine(fa._9, xb._9), xb._10)
  }
  override def productR[A, B](a: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A))(b: (A0, A1, A2, A3, A4, A5, A6, A7, A8, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), A4.combine(a._5, b._5), A5.combine(a._6, b._6), A6.combine(a._7, b._7), A7.combine(a._8, b._8), A8.combine(a._9, b._9), b._10)
  override def productL[A, B](a: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A))(b: (A0, A1, A2, A3, A4, A5, A6, A7, A8, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), A4.combine(a._5, b._5), A5.combine(a._6, b._6), A6.combine(a._7, b._7), A7.combine(a._8, b._8), A8.combine(a._9, b._9), a._10)
  override def mproduct[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A))(f: A => (A0, A1, A2, A3, A4, A5, A6, A7, A8, B)) = {
    val xb = f(fa._10)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), A4.combine(fa._5, xb._5), A5.combine(fa._6, xb._6), A6.combine(fa._7, xb._7), A7.combine(fa._8, xb._8), A8.combine(fa._9, xb._9), (fa._10, xb._10))
  }
  def tailRecM[A, B](a: A)(f: A => (A0, A1, A2, A3, A4, A5, A6, A7, A8, Either[A, B])) = {
    
    @tailrec
    def loop(b0: A0, b1: A1, b2: A2, b3: A3, b4: A4, b5: A5, b6: A6, b7: A7, b8: A8, a: A): (A0, A1, A2, A3, A4, A5, A6, A7, A8, B) =
      f(a) match {
        case (a0, a1, a2, a3, a4, a5, a6, a7, a8, Right(b))    => (A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), A4.combine(b4, a4), A5.combine(b5, a5), A6.combine(b6, a6), A7.combine(b7, a7), A8.combine(b8, a8), b)
        case (a0, a1, a2, a3, a4, a5, a6, a7, a8, Left(nextA)) => loop(A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), A4.combine(b4, a4), A5.combine(b5, a5), A6.combine(b6, a6), A7.combine(b7, a7), A8.combine(b8, a8), nextA)
      }
    f(a) match {
      case (a0, a1, a2, a3, a4, a5, a6, a7, a8, Right(b))    => (a0, a1, a2, a3, a4, a5, a6, a7, a8, b)
      case (a0, a1, a2, a3, a4, a5, a6, a7, a8, Left(nextA)) => loop(a0, a1, a2, a3, a4, a5, a6, a7, a8, nextA)
    }
  }
}

private[instances] class FlatMapTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](A0: Semigroup[A0], A1: Semigroup[A1], A2: Semigroup[A2], A3: Semigroup[A3], A4: Semigroup[A4], A5: Semigroup[A5], A6: Semigroup[A6], A7: Semigroup[A7], A8: Semigroup[A8], A9: Semigroup[A9])
    extends FlatMap[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, *)] {
  override def ap[A, B](ff: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A => B))(fa: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A)) =
    (A0.combine(ff._1, fa._1), A1.combine(ff._2, fa._2), A2.combine(ff._3, fa._3), A3.combine(ff._4, fa._4), A4.combine(ff._5, fa._5), A5.combine(ff._6, fa._6), A6.combine(ff._7, fa._7), A7.combine(ff._8, fa._8), A8.combine(ff._9, fa._9), A9.combine(ff._10, fa._10), ff._11(fa._11))
  override def product[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A), fb: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, B)) =
    (A0.combine(fa._1, fb._1), A1.combine(fa._2, fb._2), A2.combine(fa._3, fb._3), A3.combine(fa._4, fb._4), A4.combine(fa._5, fb._5), A5.combine(fa._6, fb._6), A6.combine(fa._7, fb._7), A7.combine(fa._8, fb._8), A8.combine(fa._9, fb._9), A9.combine(fa._10, fb._10), (fa._11, fb._11))
  override def map[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A))(f: A => B) =
    fa.copy(_11 = f(fa._11))
  def flatMap[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A))(f: A => (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, B)) = {
    val xb = f(fa._11)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), A4.combine(fa._5, xb._5), A5.combine(fa._6, xb._6), A6.combine(fa._7, xb._7), A7.combine(fa._8, xb._8), A8.combine(fa._9, xb._9), A9.combine(fa._10, xb._10), xb._11)
  }
  override def productR[A, B](a: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A))(b: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), A4.combine(a._5, b._5), A5.combine(a._6, b._6), A6.combine(a._7, b._7), A7.combine(a._8, b._8), A8.combine(a._9, b._9), A9.combine(a._10, b._10), b._11)
  override def productL[A, B](a: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A))(b: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, B)) =
    (A0.combine(a._1, b._1), A1.combine(a._2, b._2), A2.combine(a._3, b._3), A3.combine(a._4, b._4), A4.combine(a._5, b._5), A5.combine(a._6, b._6), A6.combine(a._7, b._7), A7.combine(a._8, b._8), A8.combine(a._9, b._9), A9.combine(a._10, b._10), a._11)
  override def mproduct[A, B](fa: (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A))(f: A => (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, B)) = {
    val xb = f(fa._11)
    (A0.combine(fa._1, xb._1), A1.combine(fa._2, xb._2), A2.combine(fa._3, xb._3), A3.combine(fa._4, xb._4), A4.combine(fa._5, xb._5), A5.combine(fa._6, xb._6), A6.combine(fa._7, xb._7), A7.combine(fa._8, xb._8), A8.combine(fa._9, xb._9), A9.combine(fa._10, xb._10), (fa._11, xb._11))
  }
  def tailRecM[A, B](a: A)(f: A => (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, Either[A, B])) = {
    
    @tailrec
    def loop(b0: A0, b1: A1, b2: A2, b3: A3, b4: A4, b5: A5, b6: A6, b7: A7, b8: A8, b9: A9, a: A): (A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, B) =
      f(a) match {
        case (a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, Right(b))    => (A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), A4.combine(b4, a4), A5.combine(b5, a5), A6.combine(b6, a6), A7.combine(b7, a7), A8.combine(b8, a8), A9.combine(b9, a9), b)
        case (a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, Left(nextA)) => loop(A0.combine(b0, a0), A1.combine(b1, a1), A2.combine(b2, a2), A3.combine(b3, a3), A4.combine(b4, a4), A5.combine(b5, a5), A6.combine(b6, a6), A7.combine(b7, a7), A8.combine(b8, a8), A9.combine(b9, a9), nextA)
      }
    f(a) match {
      case (a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, Right(b))    => (a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, b)
      case (a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, Left(nextA)) => loop(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, nextA)
    }
  }
}