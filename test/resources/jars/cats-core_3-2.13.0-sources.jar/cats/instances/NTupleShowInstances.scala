// auto-generated boilerplate by /project/Boilerplate.scala

package cats
package instances

private[cats] trait NTupleShowInstances {
  implicit final def catsStdShowForTuple1[A0](implicit A0: Show[A0]): Show[Tuple1[A0]] =
    Show.show(f => s"(${A0.show(f._1)})")
  implicit final def catsStdShowForTuple2[A0, A1](implicit A0: Show[A0], A1: Show[A1]): Show[(A0, A1)] =
    Show.show(f => s"(${A0.show(f._1)},${A1.show(f._2)})")
  implicit final def catsStdShowForTuple3[A0, A1, A2](implicit A0: Show[A0], A1: Show[A1], A2: Show[A2]): Show[(A0, A1, A2)] =
    Show.show(f => s"(${A0.show(f._1)},${A1.show(f._2)},${A2.show(f._3)})")
  implicit final def catsStdShowForTuple4[A0, A1, A2, A3](implicit A0: Show[A0], A1: Show[A1], A2: Show[A2], A3: Show[A3]): Show[(A0, A1, A2, A3)] =
    Show.show(f => s"(${A0.show(f._1)},${A1.show(f._2)},${A2.show(f._3)},${A3.show(f._4)})")
  implicit final def catsStdShowForTuple5[A0, A1, A2, A3, A4](implicit A0: Show[A0], A1: Show[A1], A2: Show[A2], A3: Show[A3], A4: Show[A4]): Show[(A0, A1, A2, A3, A4)] =
    Show.show(f => s"(${A0.show(f._1)},${A1.show(f._2)},${A2.show(f._3)},${A3.show(f._4)},${A4.show(f._5)})")
  implicit final def catsStdShowForTuple6[A0, A1, A2, A3, A4, A5](implicit A0: Show[A0], A1: Show[A1], A2: Show[A2], A3: Show[A3], A4: Show[A4], A5: Show[A5]): Show[(A0, A1, A2, A3, A4, A5)] =
    Show.show(f => s"(${A0.show(f._1)},${A1.show(f._2)},${A2.show(f._3)},${A3.show(f._4)},${A4.show(f._5)},${A5.show(f._6)})")
  implicit final def catsStdShowForTuple7[A0, A1, A2, A3, A4, A5, A6](implicit A0: Show[A0], A1: Show[A1], A2: Show[A2], A3: Show[A3], A4: Show[A4], A5: Show[A5], A6: Show[A6]): Show[(A0, A1, A2, A3, A4, A5, A6)] =
    Show.show(f => s"(${A0.show(f._1)},${A1.show(f._2)},${A2.show(f._3)},${A3.show(f._4)},${A4.show(f._5)},${A5.show(f._6)},${A6.show(f._7)})")
  implicit final def catsStdShowForTuple8[A0, A1, A2, A3, A4, A5, A6, A7](implicit A0: Show[A0], A1: Show[A1], A2: Show[A2], A3: Show[A3], A4: Show[A4], A5: Show[A5], A6: Show[A6], A7: Show[A7]): Show[(A0, A1, A2, A3, A4, A5, A6, A7)] =
    Show.show(f => s"(${A0.show(f._1)},${A1.show(f._2)},${A2.show(f._3)},${A3.show(f._4)},${A4.show(f._5)},${A5.show(f._6)},${A6.show(f._7)},${A7.show(f._8)})")
  implicit final def catsStdShowForTuple9[A0, A1, A2, A3, A4, A5, A6, A7, A8](implicit A0: Show[A0], A1: Show[A1], A2: Show[A2], A3: Show[A3], A4: Show[A4], A5: Show[A5], A6: Show[A6], A7: Show[A7], A8: Show[A8]): Show[(A0, A1, A2, A3, A4, A5, A6, A7, A8)] =
    Show.show(f => s"(${A0.show(f._1)},${A1.show(f._2)},${A2.show(f._3)},${A3.show(f._4)},${A4.show(f._5)},${A5.show(f._6)},${A6.show(f._7)},${A7.show(f._8)},${A8.show(f._9)})")
  implicit final def catsStdShowForTuple10[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](implicit A0: Show[A0], A1: Show[A1], A2: Show[A2], A3: Show[A3], A4: Show[A4], A5: Show[A5], A6: Show[A6], A7: Show[A7], A8: Show[A8], A9: Show[A9]): Show[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9)] =
    Show.show(f => s"(${A0.show(f._1)},${A1.show(f._2)},${A2.show(f._3)},${A3.show(f._4)},${A4.show(f._5)},${A5.show(f._6)},${A6.show(f._7)},${A7.show(f._8)},${A8.show(f._9)},${A9.show(f._10)})")
  implicit final def catsStdShowForTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10](implicit A0: Show[A0], A1: Show[A1], A2: Show[A2], A3: Show[A3], A4: Show[A4], A5: Show[A5], A6: Show[A6], A7: Show[A7], A8: Show[A8], A9: Show[A9], A10: Show[A10]): Show[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10)] =
    Show.show(f => s"(${A0.show(f._1)},${A1.show(f._2)},${A2.show(f._3)},${A3.show(f._4)},${A4.show(f._5)},${A5.show(f._6)},${A6.show(f._7)},${A7.show(f._8)},${A8.show(f._9)},${A9.show(f._10)},${A10.show(f._11)})")
}