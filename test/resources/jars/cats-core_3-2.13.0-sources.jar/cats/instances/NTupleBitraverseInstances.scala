// auto-generated boilerplate by /project/Boilerplate.scala

package cats
package instances

private[cats] trait NTupleBitraverseInstances {
  protected type γ[_]

  private def instance[F[_, _] <: Product](
    bitrav: (F[Any, Any], Applicative[γ], Any => γ[Any], Any => γ[Any]) => γ[F[Any, Any]]
  ): Bitraverse[F] = new Bitraverse[F] {
    def bitraverse[G[_], A, B, C, D](fab: F[A, B])(f: A => G[C], g: B => G[D])(implicit G: Applicative[G]): G[F[C, D]] =
      bitrav(
        fab.asInstanceOf[F[Any, Any]],
        G.asInstanceOf[Applicative[γ]],
        f.asInstanceOf[Any => γ[Any]],
        g.asInstanceOf[Any => γ[Any]]
      ).asInstanceOf[G[F[C, D]]]

    @inline private def last1[A, B](fab: F[A, B]): A =
      fab.productElement(fab.productArity - 2).asInstanceOf[A]
    @inline private def last2[A, B](fab: F[A, B]): B =
      fab.productElement(fab.productArity - 1).asInstanceOf[B]
    def bifoldLeft[A, B, C](fab: F[A, B], c: C)(f: (C, A) => C, g: (C, B) => C): C =
      g(f(c, last1(fab)), last2(fab))
    def bifoldRight[A, B, C](fab: F[A, B], c: Eval[C])(f: (A, Eval[C]) => Eval[C], g: (B, Eval[C]) => Eval[C]): Eval[C] =
      g(last2(fab), f(last1(fab), c))
  }

  implicit final def catsStdBitraverseForTuple2: Bitraverse[(*, *)] =
    instance { (fab, G, f, g) =>
      G.map2(f(fab._1), g(fab._2)) { (x, y) =>
        fab.copy(_1 = x, _2 = y)
      }
    }

  implicit final def catsStdBitraverseForTuple3[A0]: Bitraverse[(A0, *, *)] =
    instance { (fab, G, f, g) =>
      G.map2(f(fab._2), g(fab._3)) { (x, y) =>
        fab.copy(_2 = x, _3 = y)
      }
    }

  implicit final def catsStdBitraverseForTuple4[A0, A1]: Bitraverse[(A0, A1, *, *)] =
    instance { (fab, G, f, g) =>
      G.map2(f(fab._3), g(fab._4)) { (x, y) =>
        fab.copy(_3 = x, _4 = y)
      }
    }

  implicit final def catsStdBitraverseForTuple5[A0, A1, A2]: Bitraverse[(A0, A1, A2, *, *)] =
    instance { (fab, G, f, g) =>
      G.map2(f(fab._4), g(fab._5)) { (x, y) =>
        fab.copy(_4 = x, _5 = y)
      }
    }

  implicit final def catsStdBitraverseForTuple6[A0, A1, A2, A3]: Bitraverse[(A0, A1, A2, A3, *, *)] =
    instance { (fab, G, f, g) =>
      G.map2(f(fab._5), g(fab._6)) { (x, y) =>
        fab.copy(_5 = x, _6 = y)
      }
    }

  implicit final def catsStdBitraverseForTuple7[A0, A1, A2, A3, A4]: Bitraverse[(A0, A1, A2, A3, A4, *, *)] =
    instance { (fab, G, f, g) =>
      G.map2(f(fab._6), g(fab._7)) { (x, y) =>
        fab.copy(_6 = x, _7 = y)
      }
    }

  implicit final def catsStdBitraverseForTuple8[A0, A1, A2, A3, A4, A5]: Bitraverse[(A0, A1, A2, A3, A4, A5, *, *)] =
    instance { (fab, G, f, g) =>
      G.map2(f(fab._7), g(fab._8)) { (x, y) =>
        fab.copy(_7 = x, _8 = y)
      }
    }

  implicit final def catsStdBitraverseForTuple9[A0, A1, A2, A3, A4, A5, A6]: Bitraverse[(A0, A1, A2, A3, A4, A5, A6, *, *)] =
    instance { (fab, G, f, g) =>
      G.map2(f(fab._8), g(fab._9)) { (x, y) =>
        fab.copy(_8 = x, _9 = y)
      }
    }

  implicit final def catsStdBitraverseForTuple10[A0, A1, A2, A3, A4, A5, A6, A7]: Bitraverse[(A0, A1, A2, A3, A4, A5, A6, A7, *, *)] =
    instance { (fab, G, f, g) =>
      G.map2(f(fab._9), g(fab._10)) { (x, y) =>
        fab.copy(_9 = x, _10 = y)
      }
    }

  implicit final def catsStdBitraverseForTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8]: Bitraverse[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *, *)] =
    instance { (fab, G, f, g) =>
      G.map2(f(fab._10), g(fab._11)) { (x, y) =>
        fab.copy(_10 = x, _11 = y)
      }
    }
}