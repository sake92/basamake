// auto-generated boilerplate by /project/Boilerplate.scala

package cats
package instances

private[cats] trait NTupleBifunctorInstances {

  private def instance[F[_, _]](bim: (F[Any, Any], Any => Any, Any => Any) => F[Any, Any]): Bifunctor[F] =
    new Bifunctor[F] {
      def bimap[A, B, C, D](fab: F[A, B])(f: A => C, g: B => D): F[C, D] =
        bim(fab.asInstanceOf[F[Any, Any]], f.asInstanceOf[Any => Any], g.asInstanceOf[Any => Any]).asInstanceOf[F[C, D]]
    }

  implicit final def catsStdBifunctorForTuple2: Bifunctor[(*, *)] =
    instance[(*, *)] { (fab, f, g) =>
      fab.copy(_1 = f(fab._1), _2 = g(fab._2))
    }

  implicit final def catsStdBifunctorForTuple3[A0]: Bifunctor[(A0, *, *)] =
    instance[(A0, *, *)] { (fab, f, g) =>
      fab.copy(_2 = f(fab._2), _3 = g(fab._3))
    }

  implicit final def catsStdBifunctorForTuple4[A0, A1]: Bifunctor[(A0, A1, *, *)] =
    instance[(A0, A1, *, *)] { (fab, f, g) =>
      fab.copy(_3 = f(fab._3), _4 = g(fab._4))
    }

  implicit final def catsStdBifunctorForTuple5[A0, A1, A2]: Bifunctor[(A0, A1, A2, *, *)] =
    instance[(A0, A1, A2, *, *)] { (fab, f, g) =>
      fab.copy(_4 = f(fab._4), _5 = g(fab._5))
    }

  implicit final def catsStdBifunctorForTuple6[A0, A1, A2, A3]: Bifunctor[(A0, A1, A2, A3, *, *)] =
    instance[(A0, A1, A2, A3, *, *)] { (fab, f, g) =>
      fab.copy(_5 = f(fab._5), _6 = g(fab._6))
    }

  implicit final def catsStdBifunctorForTuple7[A0, A1, A2, A3, A4]: Bifunctor[(A0, A1, A2, A3, A4, *, *)] =
    instance[(A0, A1, A2, A3, A4, *, *)] { (fab, f, g) =>
      fab.copy(_6 = f(fab._6), _7 = g(fab._7))
    }

  implicit final def catsStdBifunctorForTuple8[A0, A1, A2, A3, A4, A5]: Bifunctor[(A0, A1, A2, A3, A4, A5, *, *)] =
    instance[(A0, A1, A2, A3, A4, A5, *, *)] { (fab, f, g) =>
      fab.copy(_7 = f(fab._7), _8 = g(fab._8))
    }

  implicit final def catsStdBifunctorForTuple9[A0, A1, A2, A3, A4, A5, A6]: Bifunctor[(A0, A1, A2, A3, A4, A5, A6, *, *)] =
    instance[(A0, A1, A2, A3, A4, A5, A6, *, *)] { (fab, f, g) =>
      fab.copy(_8 = f(fab._8), _9 = g(fab._9))
    }

  implicit final def catsStdBifunctorForTuple10[A0, A1, A2, A3, A4, A5, A6, A7]: Bifunctor[(A0, A1, A2, A3, A4, A5, A6, A7, *, *)] =
    instance[(A0, A1, A2, A3, A4, A5, A6, A7, *, *)] { (fab, f, g) =>
      fab.copy(_9 = f(fab._9), _10 = g(fab._10))
    }

  implicit final def catsStdBifunctorForTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8]: Bifunctor[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *, *)] =
    instance[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *, *)] { (fab, f, g) =>
      fab.copy(_10 = f(fab._10), _11 = g(fab._11))
    }
}