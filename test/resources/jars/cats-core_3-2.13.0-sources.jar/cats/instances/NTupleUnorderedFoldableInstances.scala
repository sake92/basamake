// auto-generated boilerplate by /project/Boilerplate.scala

package cats
package instances

private[cats] trait NTupleUnorderedFoldableInstances {
  protected type γ[_]

  private def instance[F[_] <: Product](
    trav: (F[Any], Applicative[γ], Any => γ[Any]) => γ[F[Any]]
  ): Traverse[F] with Reducible[F] =
    new Traverse[F] with Reducible[F] {
      def traverse[G[_], A, B](fa: F[A])(f: A => G[B])(implicit G: Applicative[G]) =
        trav(fa.asInstanceOf[F[Any]], G.asInstanceOf[Applicative[γ]], f.asInstanceOf[Any => γ[Any]]).asInstanceOf[G[F[B]]]
      @inline private def last[A](fa: F[A]): A =
        fa.productElement(fa.productArity - 1).asInstanceOf[A]
      def foldLeft[A, B](fa: F[A], b: B)(f: (B, A) => B): B = f(b, last(fa))
      def foldRight[A, B](fa: F[A], lb: Eval[B])(f: (A, Eval[B]) => Eval[B]): Eval[B] = f(last(fa), lb)
      override def foldMap[A, B](fa: F[A])(f: A => B)(implicit B: Monoid[B]): B = f(last(fa))
      override def reduce[A](fa: F[A])(implicit A: Semigroup[A]): A = last(fa)
      def reduceLeftTo[A, B](fa: F[A])(f: A => B)(g: (B, A) => B): B = f(last(fa))
      override def reduceLeft[A](fa: F[A])(f: (A, A) => A): A = last(fa)
      override def reduceLeftToOption[A, B](fa: F[A])(f: A => B)(g: (B, A) => B): Option[B] = Some(f(last(fa)))
      override def reduceRight[A](fa: F[A])(f: (A, Eval[A]) => Eval[A]): Eval[A] = Now(last(fa))
      def reduceRightTo[A, B](fa: F[A])(f: A => B)(g: (A, Eval[B]) => Eval[B]): Eval[B] = Now(f(last(fa)))
      override def reduceRightToOption[A, B](fa: F[A])(f: A => B)(g: (A, Eval[B]) => Eval[B]): Eval[Option[B]] = Now(Some(f(last(fa))))
      override def reduceMap[A, B](fa: F[A])(f: A => B)(implicit B: Semigroup[B]): B = f(last(fa))
      override def size[A](fa: F[A]): Long = 1L
      override def get[A](fa: F[A])(idx: Long): Option[A] = if (idx == 0L) Some(last(fa)) else None
      override def exists[A](fa: F[A])(p: A => Boolean): Boolean = p(last(fa))
      override def forall[A](fa: F[A])(p: A => Boolean): Boolean = p(last(fa))
      override def isEmpty[A](fa: F[A]): Boolean = false
    }

  implicit final def catsUnorderedFoldableInstancesForTuple1
    : Traverse[Tuple1] with Reducible[Tuple1]
    = instance((fa, G, f) => G.map(f(fa._1))(x => fa.copy(_1 = x)))

  implicit final def catsUnorderedFoldableInstancesForTuple2[A0]
    : Traverse[(A0, *)] with Reducible[(A0, *)]
    = instance((fa, G, f) => G.map(f(fa._2))(x => fa.copy(_2 = x)))

  implicit final def catsUnorderedFoldableInstancesForTuple3[A0, A1]
    : Traverse[(A0, A1, *)] with Reducible[(A0, A1, *)]
    = instance((fa, G, f) => G.map(f(fa._3))(x => fa.copy(_3 = x)))

  implicit final def catsUnorderedFoldableInstancesForTuple4[A0, A1, A2]
    : Traverse[(A0, A1, A2, *)] with Reducible[(A0, A1, A2, *)]
    = instance((fa, G, f) => G.map(f(fa._4))(x => fa.copy(_4 = x)))

  implicit final def catsUnorderedFoldableInstancesForTuple5[A0, A1, A2, A3]
    : Traverse[(A0, A1, A2, A3, *)] with Reducible[(A0, A1, A2, A3, *)]
    = instance((fa, G, f) => G.map(f(fa._5))(x => fa.copy(_5 = x)))

  implicit final def catsUnorderedFoldableInstancesForTuple6[A0, A1, A2, A3, A4]
    : Traverse[(A0, A1, A2, A3, A4, *)] with Reducible[(A0, A1, A2, A3, A4, *)]
    = instance((fa, G, f) => G.map(f(fa._6))(x => fa.copy(_6 = x)))

  implicit final def catsUnorderedFoldableInstancesForTuple7[A0, A1, A2, A3, A4, A5]
    : Traverse[(A0, A1, A2, A3, A4, A5, *)] with Reducible[(A0, A1, A2, A3, A4, A5, *)]
    = instance((fa, G, f) => G.map(f(fa._7))(x => fa.copy(_7 = x)))

  implicit final def catsUnorderedFoldableInstancesForTuple8[A0, A1, A2, A3, A4, A5, A6]
    : Traverse[(A0, A1, A2, A3, A4, A5, A6, *)] with Reducible[(A0, A1, A2, A3, A4, A5, A6, *)]
    = instance((fa, G, f) => G.map(f(fa._8))(x => fa.copy(_8 = x)))

  implicit final def catsUnorderedFoldableInstancesForTuple9[A0, A1, A2, A3, A4, A5, A6, A7]
    : Traverse[(A0, A1, A2, A3, A4, A5, A6, A7, *)] with Reducible[(A0, A1, A2, A3, A4, A5, A6, A7, *)]
    = instance((fa, G, f) => G.map(f(fa._9))(x => fa.copy(_9 = x)))

  implicit final def catsUnorderedFoldableInstancesForTuple10[A0, A1, A2, A3, A4, A5, A6, A7, A8]
    : Traverse[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *)] with Reducible[(A0, A1, A2, A3, A4, A5, A6, A7, A8, *)]
    = instance((fa, G, f) => G.map(f(fa._10))(x => fa.copy(_10 = x)))

  implicit final def catsUnorderedFoldableInstancesForTuple11[A0, A1, A2, A3, A4, A5, A6, A7, A8, A9]
    : Traverse[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, *)] with Reducible[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, *)]
    = instance((fa, G, f) => G.map(f(fa._11))(x => fa.copy(_11 = x)))
}