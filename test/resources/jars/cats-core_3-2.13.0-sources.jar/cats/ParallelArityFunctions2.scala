// auto-generated boilerplate by /project/Boilerplate.scala
package cats

/**
 * @groupprio Ungrouped 0
 *
 * @groupname ParTupleArity parTuple arity
 * @groupdesc ParTupleArity Higher-arity parTuple methods
 * @groupprio ParTupleArity 999
 */
abstract class ParallelArityFunctions2 extends ParallelArityFunctions {
  /** @group ParTupleArity */
  def parTuple2[M[_], A0, A1](m0:M[A0], m1:M[A1])(implicit p: NonEmptyParallel[M]): M[(A0, A1)] =
    parMap2(m0, m1)(Tuple2.apply)
  /** @group ParTupleArity */
  def parTuple3[M[_], A0, A1, A2](m0:M[A0], m1:M[A1], m2:M[A2])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2)] =
    parMap3(m0, m1, m2)(Tuple3.apply)
  /** @group ParTupleArity */
  def parTuple4[M[_], A0, A1, A2, A3](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3)] =
    parMap4(m0, m1, m2, m3)(Tuple4.apply)
  /** @group ParTupleArity */
  def parTuple5[M[_], A0, A1, A2, A3, A4](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4)] =
    parMap5(m0, m1, m2, m3, m4)(Tuple5.apply)
  /** @group ParTupleArity */
  def parTuple6[M[_], A0, A1, A2, A3, A4, A5](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5)] =
    parMap6(m0, m1, m2, m3, m4, m5)(Tuple6.apply)
  /** @group ParTupleArity */
  def parTuple7[M[_], A0, A1, A2, A3, A4, A5, A6](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6)] =
    parMap7(m0, m1, m2, m3, m4, m5, m6)(Tuple7.apply)
  /** @group ParTupleArity */
  def parTuple8[M[_], A0, A1, A2, A3, A4, A5, A6, A7](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7)] =
    parMap8(m0, m1, m2, m3, m4, m5, m6, m7)(Tuple8.apply)
  /** @group ParTupleArity */
  def parTuple9[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8)] =
    parMap9(m0, m1, m2, m3, m4, m5, m6, m7, m8)(Tuple9.apply)
  /** @group ParTupleArity */
  def parTuple10[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8], m9:M[A9])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9)] =
    parMap10(m0, m1, m2, m3, m4, m5, m6, m7, m8, m9)(Tuple10.apply)
  /** @group ParTupleArity */
  def parTuple11[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8], m9:M[A9], m10:M[A10])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10)] =
    parMap11(m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10)(Tuple11.apply)
  /** @group ParTupleArity */
  def parTuple12[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8], m9:M[A9], m10:M[A10], m11:M[A11])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11)] =
    parMap12(m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11)(Tuple12.apply)
  /** @group ParTupleArity */
  def parTuple13[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8], m9:M[A9], m10:M[A10], m11:M[A11], m12:M[A12])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12)] =
    parMap13(m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12)(Tuple13.apply)
  /** @group ParTupleArity */
  def parTuple14[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8], m9:M[A9], m10:M[A10], m11:M[A11], m12:M[A12], m13:M[A13])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13)] =
    parMap14(m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13)(Tuple14.apply)
  /** @group ParTupleArity */
  def parTuple15[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8], m9:M[A9], m10:M[A10], m11:M[A11], m12:M[A12], m13:M[A13], m14:M[A14])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14)] =
    parMap15(m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13, m14)(Tuple15.apply)
  /** @group ParTupleArity */
  def parTuple16[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8], m9:M[A9], m10:M[A10], m11:M[A11], m12:M[A12], m13:M[A13], m14:M[A14], m15:M[A15])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15)] =
    parMap16(m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13, m14, m15)(Tuple16.apply)
  /** @group ParTupleArity */
  def parTuple17[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8], m9:M[A9], m10:M[A10], m11:M[A11], m12:M[A12], m13:M[A13], m14:M[A14], m15:M[A15], m16:M[A16])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16)] =
    parMap17(m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13, m14, m15, m16)(Tuple17.apply)
  /** @group ParTupleArity */
  def parTuple18[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8], m9:M[A9], m10:M[A10], m11:M[A11], m12:M[A12], m13:M[A13], m14:M[A14], m15:M[A15], m16:M[A16], m17:M[A17])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17)] =
    parMap18(m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13, m14, m15, m16, m17)(Tuple18.apply)
  /** @group ParTupleArity */
  def parTuple19[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8], m9:M[A9], m10:M[A10], m11:M[A11], m12:M[A12], m13:M[A13], m14:M[A14], m15:M[A15], m16:M[A16], m17:M[A17], m18:M[A18])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18)] =
    parMap19(m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13, m14, m15, m16, m17, m18)(Tuple19.apply)
  /** @group ParTupleArity */
  def parTuple20[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8], m9:M[A9], m10:M[A10], m11:M[A11], m12:M[A12], m13:M[A13], m14:M[A14], m15:M[A15], m16:M[A16], m17:M[A17], m18:M[A18], m19:M[A19])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19)] =
    parMap20(m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13, m14, m15, m16, m17, m18, m19)(Tuple20.apply)
  /** @group ParTupleArity */
  def parTuple21[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8], m9:M[A9], m10:M[A10], m11:M[A11], m12:M[A12], m13:M[A13], m14:M[A14], m15:M[A15], m16:M[A16], m17:M[A17], m18:M[A18], m19:M[A19], m20:M[A20])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20)] =
    parMap21(m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13, m14, m15, m16, m17, m18, m19, m20)(Tuple21.apply)
  /** @group ParTupleArity */
  def parTuple22[M[_], A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21](m0:M[A0], m1:M[A1], m2:M[A2], m3:M[A3], m4:M[A4], m5:M[A5], m6:M[A6], m7:M[A7], m8:M[A8], m9:M[A9], m10:M[A10], m11:M[A11], m12:M[A12], m13:M[A13], m14:M[A14], m15:M[A15], m16:M[A16], m17:M[A17], m18:M[A18], m19:M[A19], m20:M[A20], m21:M[A21])(implicit p: NonEmptyParallel[M]): M[(A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, A21)] =
    parMap22(m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13, m14, m15, m16, m17, m18, m19, m20, m21)(Tuple22.apply)
}